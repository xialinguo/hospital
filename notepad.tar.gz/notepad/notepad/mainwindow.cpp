#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QFileInfo>
#include <QTextEdit>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Notepad");

    // 菜单动作与槽函数
    connect(ui->actionNew,  &QAction::triggered, this, &MainWindow::newFile);
    connect(ui->actionOpen, &QAction::triggered, this, &MainWindow::openFile);
    connect(ui->actionSave, &QAction::triggered, this, &MainWindow::saveFile);
    connect(ui->actionExit, &QAction::triggered, this, &QWidget::close);

    // 编辑动作直接连到 QTextEdit
    connect(ui->actionUndo,  &QAction::triggered, ui->textEdit, &QTextEdit::undo);
    connect(ui->actionRedo,  &QAction::triggered, ui->textEdit, &QTextEdit::redo);
    connect(ui->actionCut,   &QAction::triggered, ui->textEdit, &QTextEdit::cut);
    connect(ui->actionCopy,  &QAction::triggered, ui->textEdit, &QTextEdit::copy);
    connect(ui->actionPaste, &QAction::triggered, ui->textEdit, &QTextEdit::paste);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::newFile()
{
    ui->textEdit->clear();
    currentFile.clear();
    statusBar()->showMessage("New file");
}

void MainWindow::openFile()
{
    QString fileName = QFileDialog::getOpenFileName(
        this, "Open File", QString(),
        "Text Files (*.txt);;All Files (*)"
    );
    if (fileName.isEmpty()) return;

    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Cannot open file: " + file.errorString());
        return;
    }

    QTextStream in(&file);
    ui->textEdit->setPlainText(in.readAll());
    file.close();

    currentFile = fileName;
    setWindowTitle(QString("Notepad - %1").arg(QFileInfo(fileName).fileName()));
    statusBar()->showMessage("Opened");
}

void MainWindow::saveFile()
{
    QString fileName = currentFile;
    if (fileName.isEmpty()) {
        fileName = QFileDialog::getSaveFileName(
            this, "Save File", QString(),
            "Text Files (*.txt);;All Files (*)"
        );
        if (fileName.isEmpty()) return;
        currentFile = fileName;
    }

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::warning(this, "Error", "Cannot save file: " + file.errorString());
        return;
    }

    QTextStream out(&file);
    out << ui->textEdit->toPlainText();
    file.close();
    statusBar()->showMessage("Saved");
}
