#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <cmath>       // pow
#include <QString>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_calcButton_clicked()
{
    // 读取输入
    double pv = ui->pvLineEdit->text().toDouble();
    double r = ui->rateLineEdit->text().toDouble();
    int n = ui->periodsLineEdit->text().toInt();

    // 复利公式 FV = PV * (1 + r)^n
    double fv = pv * std::pow(1 + r, n);

    // 显示结果
    ui->resultLabel->setText(QString("复利终值为: %1").arg(fv, 0, 'f', 2));
}
