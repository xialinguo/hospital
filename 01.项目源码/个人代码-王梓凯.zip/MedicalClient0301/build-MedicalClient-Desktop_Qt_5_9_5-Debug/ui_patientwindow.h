/********************************************************************************
** Form generated from reading UI file 'patientwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PATIENTWINDOW_H
#define UI_PATIENTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PatientWindow
{
public:
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *navLayout;
    QPushButton *appointmentButton;
    QPushButton *medicalHistoryButton;
    QPushButton *chatButton;
    QPushButton *healthAssessmentButton;
    QStackedWidget *stackedWidget;
    QPushButton *logoutButton;

    void setupUi(QMainWindow *PatientWindow)
    {
        if (PatientWindow->objectName().isEmpty())
            PatientWindow->setObjectName(QStringLiteral("PatientWindow"));
        PatientWindow->resize(945, 631);
        centralwidget = new QWidget(PatientWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(10);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(-1, -1, 6, 5);
        navLayout = new QHBoxLayout();
        navLayout->setObjectName(QStringLiteral("navLayout"));
        appointmentButton = new QPushButton(centralwidget);
        appointmentButton->setObjectName(QStringLiteral("appointmentButton"));
        appointmentButton->setMinimumSize(QSize(120, 40));

        navLayout->addWidget(appointmentButton);

        medicalHistoryButton = new QPushButton(centralwidget);
        medicalHistoryButton->setObjectName(QStringLiteral("medicalHistoryButton"));
        medicalHistoryButton->setMinimumSize(QSize(120, 40));

        navLayout->addWidget(medicalHistoryButton);

        chatButton = new QPushButton(centralwidget);
        chatButton->setObjectName(QStringLiteral("chatButton"));
        chatButton->setMinimumSize(QSize(120, 40));

        navLayout->addWidget(chatButton);

        healthAssessmentButton = new QPushButton(centralwidget);
        healthAssessmentButton->setObjectName(QStringLiteral("healthAssessmentButton"));
        healthAssessmentButton->setMinimumSize(QSize(120, 40));

        navLayout->addWidget(healthAssessmentButton);


        verticalLayout_2->addLayout(navLayout);

        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setMinimumSize(QSize(600, 400));

        verticalLayout_2->addWidget(stackedWidget);

        logoutButton = new QPushButton(centralwidget);
        logoutButton->setObjectName(QStringLiteral("logoutButton"));
        logoutButton->setMinimumSize(QSize(100, 35));

        verticalLayout_2->addWidget(logoutButton);


        verticalLayout->addLayout(verticalLayout_2);

        PatientWindow->setCentralWidget(centralwidget);

        retranslateUi(PatientWindow);

        stackedWidget->setCurrentIndex(-1);


        QMetaObject::connectSlotsByName(PatientWindow);
    } // setupUi

    void retranslateUi(QMainWindow *PatientWindow)
    {
        PatientWindow->setWindowTitle(QApplication::translate("PatientWindow", "\346\231\272\346\205\247\345\214\273\347\226\227\347\256\241\347\220\206\347\263\273\347\273\237 - \346\202\243\350\200\205\347\253\257  ", Q_NULLPTR));
        appointmentButton->setText(QApplication::translate("PatientWindow", "\351\242\204\347\272\246\346\214\202\345\217\267", Q_NULLPTR));
        medicalHistoryButton->setText(QApplication::translate("PatientWindow", "\346\210\221\347\232\204\347\227\205\345\216\206", Q_NULLPTR));
        chatButton->setText(QApplication::translate("PatientWindow", "\345\214\273\346\202\243\346\262\237\351\200\232", Q_NULLPTR));
        healthAssessmentButton->setText(QApplication::translate("PatientWindow", "\345\201\245\345\272\267\350\257\204\344\274\260", Q_NULLPTR));
        logoutButton->setText(QApplication::translate("PatientWindow", "\351\200\200\345\207\272\347\231\273\345\275\225", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class PatientWindow: public Ui_PatientWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PATIENTWINDOW_H
