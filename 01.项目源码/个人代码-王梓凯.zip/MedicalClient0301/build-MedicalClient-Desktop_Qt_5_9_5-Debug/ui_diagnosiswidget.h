/********************************************************************************
** Form generated from reading UI file 'diagnosiswidget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIAGNOSISWIDGET_H
#define UI_DIAGNOSISWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DiagnosisWidget
{
public:
    QVBoxLayout *verticalLayout;
    QVBoxLayout *verticalLayout_2;
    QLabel *titlelabel;
    QGroupBox *patientGroup;
    QVBoxLayout *verticalLayout_3;
    QLabel *complaintLabel;
    QTextEdit *chiefComplaintEdit;
    QHBoxLayout *buttonLayout;
    QPushButton *clearButton;
    QPushButton *submitButton;
    QGroupBox *doctorGroup;
    QVBoxLayout *verticalLayout_4;
    QLabel *diagnosisLabel;
    QTextEdit *diagnosisResultEdit;
    QLabel *prescriptionLabel;
    QTextEdit *prescriptionEdit;

    void setupUi(QWidget *DiagnosisWidget)
    {
        if (DiagnosisWidget->objectName().isEmpty())
            DiagnosisWidget->setObjectName(QStringLiteral("DiagnosisWidget"));
        DiagnosisWidget->resize(1114, 915);
        DiagnosisWidget->setMinimumSize(QSize(400, 300));
        verticalLayout = new QVBoxLayout(DiagnosisWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setSpacing(10);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(-1, -1, -1, 5);
        titlelabel = new QLabel(DiagnosisWidget);
        titlelabel->setObjectName(QStringLiteral("titlelabel"));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        titlelabel->setFont(font);
        titlelabel->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(titlelabel);

        patientGroup = new QGroupBox(DiagnosisWidget);
        patientGroup->setObjectName(QStringLiteral("patientGroup"));
        patientGroup->setMaximumSize(QSize(16777215, 300));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        patientGroup->setFont(font1);
        verticalLayout_3 = new QVBoxLayout(patientGroup);
        verticalLayout_3->setObjectName(QStringLiteral("verticalLayout_3"));
        complaintLabel = new QLabel(patientGroup);
        complaintLabel->setObjectName(QStringLiteral("complaintLabel"));
        complaintLabel->setMaximumSize(QSize(16777215, 16777215));
        QFont font2;
        font2.setPointSize(11);
        font2.setBold(false);
        font2.setWeight(50);
        complaintLabel->setFont(font2);
        complaintLabel->setWordWrap(true);

        verticalLayout_3->addWidget(complaintLabel);

        chiefComplaintEdit = new QTextEdit(patientGroup);
        chiefComplaintEdit->setObjectName(QStringLiteral("chiefComplaintEdit"));
        chiefComplaintEdit->setMaximumSize(QSize(16777215, 16777215));

        verticalLayout_3->addWidget(chiefComplaintEdit);

        buttonLayout = new QHBoxLayout();
        buttonLayout->setSpacing(20);
        buttonLayout->setObjectName(QStringLiteral("buttonLayout"));
        buttonLayout->setContentsMargins(10, 10, 10, 10);
        clearButton = new QPushButton(patientGroup);
        clearButton->setObjectName(QStringLiteral("clearButton"));

        buttonLayout->addWidget(clearButton);

        submitButton = new QPushButton(patientGroup);
        submitButton->setObjectName(QStringLiteral("submitButton"));
        submitButton->setMinimumSize(QSize(120, 20));

        buttonLayout->addWidget(submitButton);


        verticalLayout_3->addLayout(buttonLayout);


        verticalLayout_2->addWidget(patientGroup);

        doctorGroup = new QGroupBox(DiagnosisWidget);
        doctorGroup->setObjectName(QStringLiteral("doctorGroup"));
        doctorGroup->setMinimumSize(QSize(0, 300));
        doctorGroup->setFont(font1);
        verticalLayout_4 = new QVBoxLayout(doctorGroup);
        verticalLayout_4->setObjectName(QStringLiteral("verticalLayout_4"));
        diagnosisLabel = new QLabel(doctorGroup);
        diagnosisLabel->setObjectName(QStringLiteral("diagnosisLabel"));
        diagnosisLabel->setFont(font2);

        verticalLayout_4->addWidget(diagnosisLabel);

        diagnosisResultEdit = new QTextEdit(doctorGroup);
        diagnosisResultEdit->setObjectName(QStringLiteral("diagnosisResultEdit"));
        diagnosisResultEdit->setReadOnly(true);

        verticalLayout_4->addWidget(diagnosisResultEdit);

        prescriptionLabel = new QLabel(doctorGroup);
        prescriptionLabel->setObjectName(QStringLiteral("prescriptionLabel"));
        prescriptionLabel->setFont(font2);

        verticalLayout_4->addWidget(prescriptionLabel);

        prescriptionEdit = new QTextEdit(doctorGroup);
        prescriptionEdit->setObjectName(QStringLiteral("prescriptionEdit"));
        prescriptionEdit->setReadOnly(true);

        verticalLayout_4->addWidget(prescriptionEdit);


        verticalLayout_2->addWidget(doctorGroup);


        verticalLayout->addLayout(verticalLayout_2);


        retranslateUi(DiagnosisWidget);

        QMetaObject::connectSlotsByName(DiagnosisWidget);
    } // setupUi

    void retranslateUi(QWidget *DiagnosisWidget)
    {
        DiagnosisWidget->setWindowTitle(QApplication::translate("DiagnosisWidget", "\350\257\212\346\226\255\344\270\216\345\214\273\345\230\261", Q_NULLPTR));
        titlelabel->setText(QApplication::translate("DiagnosisWidget", "\350\257\212\346\226\255\344\270\216\345\214\273\345\230\261", Q_NULLPTR));
        patientGroup->setTitle(QApplication::translate("DiagnosisWidget", "\346\202\243\350\200\205\344\270\273\350\257\211", Q_NULLPTR));
        complaintLabel->setText(QApplication::translate("DiagnosisWidget", "\350\257\267\350\257\246\347\273\206\346\217\217\350\277\260\346\202\250\347\232\204\344\270\215\351\200\202\347\227\207\347\212\266\343\200\201\346\214\201\347\273\255\346\227\266\351\227\264\343\200\201\345\212\240\351\207\215\346\210\226\347\274\223\350\247\243\345\233\240\347\264\240\347\255\211\344\277\241\346\201\257\357\274\232", Q_NULLPTR));
        chiefComplaintEdit->setPlaceholderText(QApplication::translate("DiagnosisWidget", "\344\276\213\345\246\202\357\274\232\345\244\264\347\227\2333\345\244\251\357\274\214\344\274\264\346\234\211\346\201\266\345\277\203\357\274\214\344\274\221\346\201\257\345\220\216\347\250\215\347\274\223\350\247\243...", Q_NULLPTR));
        clearButton->setText(QApplication::translate("DiagnosisWidget", "\346\270\205\347\251\272", Q_NULLPTR));
        submitButton->setText(QApplication::translate("DiagnosisWidget", "\346\217\220\344\272\244\344\270\273\350\257\211", Q_NULLPTR));
        doctorGroup->setTitle(QApplication::translate("DiagnosisWidget", "\345\214\273\347\224\237\350\257\212\346\226\255\347\273\223\346\236\234", Q_NULLPTR));
        diagnosisLabel->setText(QApplication::translate("DiagnosisWidget", "\350\257\212\346\226\255\347\273\223\346\236\234\357\274\232", Q_NULLPTR));
        diagnosisResultEdit->setPlaceholderText(QApplication::translate("DiagnosisWidget", "\347\255\211\345\276\205\345\214\273\347\224\237\350\257\212\346\226\255...", Q_NULLPTR));
        prescriptionLabel->setText(QApplication::translate("DiagnosisWidget", "\345\244\204\346\226\271\344\270\216\345\214\273\345\230\261\357\274\232", Q_NULLPTR));
        prescriptionEdit->setPlaceholderText(QApplication::translate("DiagnosisWidget", "\347\255\211\345\276\205\345\214\273\347\224\237\345\274\200\345\205\267\345\244\204\346\226\271...", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class DiagnosisWidget: public Ui_DiagnosisWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIAGNOSISWIDGET_H
