/********************************************************************************
** Form generated from reading UI file 'doctorselectionwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DOCTORSELECTIONWIDGET_H
#define UI_DOCTORSELECTIONWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DoctorSelectionWidget
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QListWidget *doctorListWidget;
    QPushButton *selectButton;

    void setupUi(QWidget *DoctorSelectionWidget)
    {
        if (DoctorSelectionWidget->objectName().isEmpty())
            DoctorSelectionWidget->setObjectName(QStringLiteral("DoctorSelectionWidget"));
        DoctorSelectionWidget->resize(400, 300);
        verticalLayout = new QVBoxLayout(DoctorSelectionWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label = new QLabel(DoctorSelectionWidget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        doctorListWidget = new QListWidget(DoctorSelectionWidget);
        doctorListWidget->setObjectName(QStringLiteral("doctorListWidget"));

        verticalLayout->addWidget(doctorListWidget);

        selectButton = new QPushButton(DoctorSelectionWidget);
        selectButton->setObjectName(QStringLiteral("selectButton"));

        verticalLayout->addWidget(selectButton);


        retranslateUi(DoctorSelectionWidget);

        QMetaObject::connectSlotsByName(DoctorSelectionWidget);
    } // setupUi

    void retranslateUi(QWidget *DoctorSelectionWidget)
    {
        DoctorSelectionWidget->setWindowTitle(QApplication::translate("DoctorSelectionWidget", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("DoctorSelectionWidget", "\350\257\267\351\200\211\346\213\251\345\214\273\347\224\237", Q_NULLPTR));
        selectButton->setText(QApplication::translate("DoctorSelectionWidget", "\350\277\233\345\205\245\350\257\212\345\256\244", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class DoctorSelectionWidget: public Ui_DoctorSelectionWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DOCTORSELECTIONWIDGET_H
