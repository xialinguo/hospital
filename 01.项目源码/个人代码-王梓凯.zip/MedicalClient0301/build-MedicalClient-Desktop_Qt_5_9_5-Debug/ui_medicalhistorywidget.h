/********************************************************************************
** Form generated from reading UI file 'medicalhistorywidget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MEDICALHISTORYWIDGET_H
#define UI_MEDICALHISTORYWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MedicalHistoryWidget
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *titleLabel;
    QSplitter *splitter;
    QGroupBox *historyBox;
    QVBoxLayout *verticalLayout_2;
    QListWidget *historyListWidget;
    QTextBrowser *detailBrowser;
    QGroupBox *newRequestBox;
    QFormLayout *formLayout;
    QLabel *doctorLabel;
    QComboBox *doctorComboBox;
    QLabel *complaintLabel;
    QTextEdit *complaintTextEdit;
    QPushButton *submitButton;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QPushButton *backButton;

    void setupUi(QWidget *MedicalHistoryWidget)
    {
        if (MedicalHistoryWidget->objectName().isEmpty())
            MedicalHistoryWidget->setObjectName(QStringLiteral("MedicalHistoryWidget"));
        MedicalHistoryWidget->resize(900, 600);
        verticalLayout = new QVBoxLayout(MedicalHistoryWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        titleLabel = new QLabel(MedicalHistoryWidget);
        titleLabel->setObjectName(QStringLiteral("titleLabel"));
        QFont font;
        font.setPointSize(20);
        font.setBold(true);
        font.setWeight(75);
        titleLabel->setFont(font);
        titleLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(titleLabel);

        splitter = new QSplitter(MedicalHistoryWidget);
        splitter->setObjectName(QStringLiteral("splitter"));
        splitter->setOrientation(Qt::Horizontal);
        historyBox = new QGroupBox(splitter);
        historyBox->setObjectName(QStringLiteral("historyBox"));
        verticalLayout_2 = new QVBoxLayout(historyBox);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        historyListWidget = new QListWidget(historyBox);
        historyListWidget->setObjectName(QStringLiteral("historyListWidget"));

        verticalLayout_2->addWidget(historyListWidget);

        detailBrowser = new QTextBrowser(historyBox);
        detailBrowser->setObjectName(QStringLiteral("detailBrowser"));

        verticalLayout_2->addWidget(detailBrowser);

        splitter->addWidget(historyBox);
        newRequestBox = new QGroupBox(splitter);
        newRequestBox->setObjectName(QStringLiteral("newRequestBox"));
        formLayout = new QFormLayout(newRequestBox);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        doctorLabel = new QLabel(newRequestBox);
        doctorLabel->setObjectName(QStringLiteral("doctorLabel"));

        formLayout->setWidget(0, QFormLayout::LabelRole, doctorLabel);

        doctorComboBox = new QComboBox(newRequestBox);
        doctorComboBox->setObjectName(QStringLiteral("doctorComboBox"));

        formLayout->setWidget(0, QFormLayout::FieldRole, doctorComboBox);

        complaintLabel = new QLabel(newRequestBox);
        complaintLabel->setObjectName(QStringLiteral("complaintLabel"));

        formLayout->setWidget(1, QFormLayout::LabelRole, complaintLabel);

        complaintTextEdit = new QTextEdit(newRequestBox);
        complaintTextEdit->setObjectName(QStringLiteral("complaintTextEdit"));

        formLayout->setWidget(1, QFormLayout::FieldRole, complaintTextEdit);

        submitButton = new QPushButton(newRequestBox);
        submitButton->setObjectName(QStringLiteral("submitButton"));

        formLayout->setWidget(2, QFormLayout::FieldRole, submitButton);

        splitter->addWidget(newRequestBox);

        verticalLayout->addWidget(splitter);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        backButton = new QPushButton(MedicalHistoryWidget);
        backButton->setObjectName(QStringLiteral("backButton"));

        horizontalLayout->addWidget(backButton);


        verticalLayout->addLayout(horizontalLayout);


        retranslateUi(MedicalHistoryWidget);

        QMetaObject::connectSlotsByName(MedicalHistoryWidget);
    } // setupUi

    void retranslateUi(QWidget *MedicalHistoryWidget)
    {
        MedicalHistoryWidget->setWindowTitle(QApplication::translate("MedicalHistoryWidget", "Form", Q_NULLPTR));
        titleLabel->setText(QApplication::translate("MedicalHistoryWidget", "\346\210\221\347\232\204\345\260\261\350\257\212\350\256\260\345\275\225", Q_NULLPTR));
        historyBox->setTitle(QApplication::translate("MedicalHistoryWidget", "\345\216\206\345\217\262\350\256\260\345\275\225", Q_NULLPTR));
        detailBrowser->setPlaceholderText(QApplication::translate("MedicalHistoryWidget", "\347\202\271\345\207\273\344\270\212\346\226\271\345\210\227\350\241\250\346\237\245\347\234\213\350\257\246\346\203\205...", Q_NULLPTR));
        newRequestBox->setTitle(QApplication::translate("MedicalHistoryWidget", "\345\217\221\350\265\267\346\226\260\347\232\204\351\227\256\350\257\212", Q_NULLPTR));
        doctorLabel->setText(QApplication::translate("MedicalHistoryWidget", "\351\200\211\346\213\251\345\214\273\347\224\237:", Q_NULLPTR));
        complaintLabel->setText(QApplication::translate("MedicalHistoryWidget", "\347\227\205\346\203\205\344\270\273\350\257\211:", Q_NULLPTR));
        complaintTextEdit->setPlaceholderText(QApplication::translate("MedicalHistoryWidget", "\350\257\267\350\257\246\347\273\206\346\217\217\350\277\260\346\202\250\347\232\204\347\227\207\347\212\266\343\200\201\346\204\237\345\217\227\343\200\201\346\214\201\347\273\255\346\227\266\351\227\264\347\255\211\357\274\214\344\273\245\344\276\277\345\214\273\347\224\237\350\257\212\346\226\255\343\200\202", Q_NULLPTR));
        submitButton->setText(QApplication::translate("MedicalHistoryWidget", "\346\217\220\344\272\244\351\227\256\350\257\212", Q_NULLPTR));
        backButton->setText(QApplication::translate("MedicalHistoryWidget", "\350\277\224\345\233\236\344\270\273\350\217\234\345\215\225", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MedicalHistoryWidget: public Ui_MedicalHistoryWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MEDICALHISTORYWIDGET_H
