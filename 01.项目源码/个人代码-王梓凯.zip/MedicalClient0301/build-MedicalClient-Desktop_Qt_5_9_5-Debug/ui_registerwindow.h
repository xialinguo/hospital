/********************************************************************************
** Form generated from reading UI file 'registerwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTERWINDOW_H
#define UI_REGISTERWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_RegisterWindow
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *titleLabel;
    QFormLayout *formLayout;
    QLabel *Label;
    QLineEdit *usernameEdit;
    QLabel *Label_2;
    QLineEdit *passwordEdit;
    QLabel *Label_3;
    QLineEdit *confirmPasswordEdit;
    QLabel *Label_4;
    QLineEdit *realNameEdit;
    QLabel *Label_5;
    QLineEdit *phoneEdit;
    QLabel *Label_6;
    QLineEdit *idCardEdit;
    QLabel *genderLabel;
    QHBoxLayout *genderLayout;
    QRadioButton *maleRadioButton;
    QRadioButton *femaleRadioButton;
    QHBoxLayout *buttonLayout;
    QPushButton *registerConfirmButton;
    QPushButton *backToLoginButton;

    void setupUi(QWidget *RegisterWindow)
    {
        if (RegisterWindow->objectName().isEmpty())
            RegisterWindow->setObjectName(QStringLiteral("RegisterWindow"));
        RegisterWindow->resize(500, 548);
        verticalLayout = new QVBoxLayout(RegisterWindow);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        titleLabel = new QLabel(RegisterWindow);
        titleLabel->setObjectName(QStringLiteral("titleLabel"));
        QFont font;
        font.setPointSize(16);
        font.setBold(true);
        font.setWeight(75);
        titleLabel->setFont(font);
        titleLabel->setFrameShape(QFrame::Panel);
        titleLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(titleLabel);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QStringLiteral("formLayout"));
        Label = new QLabel(RegisterWindow);
        Label->setObjectName(QStringLiteral("Label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, Label);

        usernameEdit = new QLineEdit(RegisterWindow);
        usernameEdit->setObjectName(QStringLiteral("usernameEdit"));

        formLayout->setWidget(0, QFormLayout::FieldRole, usernameEdit);

        Label_2 = new QLabel(RegisterWindow);
        Label_2->setObjectName(QStringLiteral("Label_2"));

        formLayout->setWidget(1, QFormLayout::LabelRole, Label_2);

        passwordEdit = new QLineEdit(RegisterWindow);
        passwordEdit->setObjectName(QStringLiteral("passwordEdit"));
        passwordEdit->setEchoMode(QLineEdit::Password);

        formLayout->setWidget(1, QFormLayout::FieldRole, passwordEdit);

        Label_3 = new QLabel(RegisterWindow);
        Label_3->setObjectName(QStringLiteral("Label_3"));

        formLayout->setWidget(2, QFormLayout::LabelRole, Label_3);

        confirmPasswordEdit = new QLineEdit(RegisterWindow);
        confirmPasswordEdit->setObjectName(QStringLiteral("confirmPasswordEdit"));
        confirmPasswordEdit->setEchoMode(QLineEdit::Password);

        formLayout->setWidget(2, QFormLayout::FieldRole, confirmPasswordEdit);

        Label_4 = new QLabel(RegisterWindow);
        Label_4->setObjectName(QStringLiteral("Label_4"));

        formLayout->setWidget(3, QFormLayout::LabelRole, Label_4);

        realNameEdit = new QLineEdit(RegisterWindow);
        realNameEdit->setObjectName(QStringLiteral("realNameEdit"));

        formLayout->setWidget(3, QFormLayout::FieldRole, realNameEdit);

        Label_5 = new QLabel(RegisterWindow);
        Label_5->setObjectName(QStringLiteral("Label_5"));

        formLayout->setWidget(5, QFormLayout::LabelRole, Label_5);

        phoneEdit = new QLineEdit(RegisterWindow);
        phoneEdit->setObjectName(QStringLiteral("phoneEdit"));

        formLayout->setWidget(5, QFormLayout::FieldRole, phoneEdit);

        Label_6 = new QLabel(RegisterWindow);
        Label_6->setObjectName(QStringLiteral("Label_6"));

        formLayout->setWidget(6, QFormLayout::LabelRole, Label_6);

        idCardEdit = new QLineEdit(RegisterWindow);
        idCardEdit->setObjectName(QStringLiteral("idCardEdit"));
        idCardEdit->setMaxLength(18);

        formLayout->setWidget(6, QFormLayout::FieldRole, idCardEdit);

        genderLabel = new QLabel(RegisterWindow);
        genderLabel->setObjectName(QStringLiteral("genderLabel"));

        formLayout->setWidget(4, QFormLayout::LabelRole, genderLabel);

        genderLayout = new QHBoxLayout();
        genderLayout->setObjectName(QStringLiteral("genderLayout"));
        maleRadioButton = new QRadioButton(RegisterWindow);
        maleRadioButton->setObjectName(QStringLiteral("maleRadioButton"));
        maleRadioButton->setCheckable(true);
        maleRadioButton->setChecked(true);

        genderLayout->addWidget(maleRadioButton);

        femaleRadioButton = new QRadioButton(RegisterWindow);
        femaleRadioButton->setObjectName(QStringLiteral("femaleRadioButton"));

        genderLayout->addWidget(femaleRadioButton);


        formLayout->setLayout(4, QFormLayout::FieldRole, genderLayout);


        verticalLayout->addLayout(formLayout);

        buttonLayout = new QHBoxLayout();
        buttonLayout->setObjectName(QStringLiteral("buttonLayout"));
        registerConfirmButton = new QPushButton(RegisterWindow);
        registerConfirmButton->setObjectName(QStringLiteral("registerConfirmButton"));
        registerConfirmButton->setMinimumSize(QSize(100, 35));

        buttonLayout->addWidget(registerConfirmButton);

        backToLoginButton = new QPushButton(RegisterWindow);
        backToLoginButton->setObjectName(QStringLiteral("backToLoginButton"));
        backToLoginButton->setMinimumSize(QSize(100, 35));

        buttonLayout->addWidget(backToLoginButton);


        verticalLayout->addLayout(buttonLayout);


        retranslateUi(RegisterWindow);

        QMetaObject::connectSlotsByName(RegisterWindow);
    } // setupUi

    void retranslateUi(QWidget *RegisterWindow)
    {
        RegisterWindow->setWindowTitle(QApplication::translate("RegisterWindow", "\347\224\250\346\210\267\346\263\250\345\206\214", Q_NULLPTR));
        titleLabel->setText(QApplication::translate("RegisterWindow", "\347\224\250\346\210\267\346\263\250\345\206\214", Q_NULLPTR));
        Label->setText(QApplication::translate("RegisterWindow", "\347\224\250\346\210\267\345\220\215\357\274\232", Q_NULLPTR));
        usernameEdit->setPlaceholderText(QApplication::translate("RegisterWindow", "\350\257\267\350\276\223\345\205\245\347\224\250\346\210\267\345\220\215", Q_NULLPTR));
        Label_2->setText(QApplication::translate("RegisterWindow", "\345\257\206\347\240\201\357\274\232", Q_NULLPTR));
        passwordEdit->setPlaceholderText(QApplication::translate("RegisterWindow", "\350\257\267\350\276\223\345\205\245\345\257\206\347\240\201", Q_NULLPTR));
        Label_3->setText(QApplication::translate("RegisterWindow", "\347\241\256\350\256\244\345\257\206\347\240\201\357\274\232", Q_NULLPTR));
        confirmPasswordEdit->setPlaceholderText(QApplication::translate("RegisterWindow", "\350\257\267\345\206\215\346\254\241\350\276\223\345\205\245\345\257\206\347\240\201  ", Q_NULLPTR));
        Label_4->setText(QApplication::translate("RegisterWindow", "\347\234\237\345\256\236\345\247\223\345\220\215\357\274\232", Q_NULLPTR));
        realNameEdit->setPlaceholderText(QApplication::translate("RegisterWindow", "\350\257\267\350\276\223\345\205\245\347\234\237\345\256\236\345\247\223\345\220\215", Q_NULLPTR));
        Label_5->setText(QApplication::translate("RegisterWindow", "\346\211\213\346\234\272\345\217\267", Q_NULLPTR));
        phoneEdit->setInputMask(QString());
        phoneEdit->setPlaceholderText(QApplication::translate("RegisterWindow", "\350\257\267\350\276\223\345\205\245\346\211\213\346\234\272\345\217\267\347\240\201", Q_NULLPTR));
        Label_6->setText(QApplication::translate("RegisterWindow", "\350\272\253\344\273\275\350\257\201\345\217\267\357\274\232", Q_NULLPTR));
        idCardEdit->setPlaceholderText(QApplication::translate("RegisterWindow", "\350\257\267\350\276\223\345\205\245\350\272\253\344\273\275\350\257\201\345\217\267\347\240\201", Q_NULLPTR));
        genderLabel->setText(QApplication::translate("RegisterWindow", "\346\200\247\345\210\253\357\274\232", Q_NULLPTR));
        maleRadioButton->setText(QApplication::translate("RegisterWindow", "\347\224\267", Q_NULLPTR));
        femaleRadioButton->setText(QApplication::translate("RegisterWindow", "\345\245\263", Q_NULLPTR));
        registerConfirmButton->setText(QApplication::translate("RegisterWindow", "\347\241\256\350\256\244\346\263\250\345\206\214", Q_NULLPTR));
        backToLoginButton->setText(QApplication::translate("RegisterWindow", "\350\277\224\345\233\236\347\231\273\345\275\225", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class RegisterWindow: public Ui_RegisterWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTERWINDOW_H
