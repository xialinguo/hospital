/********************************************************************************
** Form generated from reading UI file 'healthassessmentwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HEALTHASSESSMENTWIDGET_H
#define UI_HEALTHASSESSMENTWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_HealthAssessmentWidget
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *titleLabel;
    QFormLayout *formLayout;
    QLabel *cmLabel;
    QSpinBox *heightSpinBox;
    QLabel *kgLabel;
    QSpinBox *weightSpinBox;
    QLabel *Label;
    QSpinBox *bpHighSpinBox;
    QLabel *Label_2;
    QSpinBox *bpLowSpinBox;
    QLabel *Label_3;
    QSpinBox *heartRateSpinBox;
    QHBoxLayout *buttonLayout;
    QPushButton *assessButton;
    QPushButton *resetButton;
    QTextEdit *resultTextEdit;

    void setupUi(QWidget *HealthAssessmentWidget)
    {
        if (HealthAssessmentWidget->objectName().isEmpty())
            HealthAssessmentWidget->setObjectName(QStringLiteral("HealthAssessmentWidget"));
        HealthAssessmentWidget->resize(400, 300);
        verticalLayout = new QVBoxLayout(HealthAssessmentWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        titleLabel = new QLabel(HealthAssessmentWidget);
        titleLabel->setObjectName(QStringLiteral("titleLabel"));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        titleLabel->setFont(font);
        titleLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(titleLabel);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QStringLiteral("formLayout"));
        cmLabel = new QLabel(HealthAssessmentWidget);
        cmLabel->setObjectName(QStringLiteral("cmLabel"));

        formLayout->setWidget(0, QFormLayout::LabelRole, cmLabel);

        heightSpinBox = new QSpinBox(HealthAssessmentWidget);
        heightSpinBox->setObjectName(QStringLiteral("heightSpinBox"));
        heightSpinBox->setMinimum(100);
        heightSpinBox->setMaximum(220);

        formLayout->setWidget(0, QFormLayout::FieldRole, heightSpinBox);

        kgLabel = new QLabel(HealthAssessmentWidget);
        kgLabel->setObjectName(QStringLiteral("kgLabel"));

        formLayout->setWidget(1, QFormLayout::LabelRole, kgLabel);

        weightSpinBox = new QSpinBox(HealthAssessmentWidget);
        weightSpinBox->setObjectName(QStringLiteral("weightSpinBox"));
        weightSpinBox->setMinimum(30);
        weightSpinBox->setMaximum(150);

        formLayout->setWidget(1, QFormLayout::FieldRole, weightSpinBox);

        Label = new QLabel(HealthAssessmentWidget);
        Label->setObjectName(QStringLiteral("Label"));

        formLayout->setWidget(2, QFormLayout::LabelRole, Label);

        bpHighSpinBox = new QSpinBox(HealthAssessmentWidget);
        bpHighSpinBox->setObjectName(QStringLiteral("bpHighSpinBox"));
        bpHighSpinBox->setMinimum(60);
        bpHighSpinBox->setMaximum(200);

        formLayout->setWidget(2, QFormLayout::FieldRole, bpHighSpinBox);

        Label_2 = new QLabel(HealthAssessmentWidget);
        Label_2->setObjectName(QStringLiteral("Label_2"));

        formLayout->setWidget(3, QFormLayout::LabelRole, Label_2);

        bpLowSpinBox = new QSpinBox(HealthAssessmentWidget);
        bpLowSpinBox->setObjectName(QStringLiteral("bpLowSpinBox"));
        bpLowSpinBox->setMinimum(40);
        bpLowSpinBox->setMaximum(120);

        formLayout->setWidget(3, QFormLayout::FieldRole, bpLowSpinBox);

        Label_3 = new QLabel(HealthAssessmentWidget);
        Label_3->setObjectName(QStringLiteral("Label_3"));

        formLayout->setWidget(4, QFormLayout::LabelRole, Label_3);

        heartRateSpinBox = new QSpinBox(HealthAssessmentWidget);
        heartRateSpinBox->setObjectName(QStringLiteral("heartRateSpinBox"));
        heartRateSpinBox->setMinimum(40);
        heartRateSpinBox->setMaximum(120);

        formLayout->setWidget(4, QFormLayout::FieldRole, heartRateSpinBox);


        verticalLayout->addLayout(formLayout);

        buttonLayout = new QHBoxLayout();
        buttonLayout->setObjectName(QStringLiteral("buttonLayout"));
        assessButton = new QPushButton(HealthAssessmentWidget);
        assessButton->setObjectName(QStringLiteral("assessButton"));
        assessButton->setMinimumSize(QSize(80, 30));

        buttonLayout->addWidget(assessButton);

        resetButton = new QPushButton(HealthAssessmentWidget);
        resetButton->setObjectName(QStringLiteral("resetButton"));
        resetButton->setMinimumSize(QSize(80, 30));

        buttonLayout->addWidget(resetButton);


        verticalLayout->addLayout(buttonLayout);

        resultTextEdit = new QTextEdit(HealthAssessmentWidget);
        resultTextEdit->setObjectName(QStringLiteral("resultTextEdit"));
        resultTextEdit->setReadOnly(true);

        verticalLayout->addWidget(resultTextEdit);


        retranslateUi(HealthAssessmentWidget);

        QMetaObject::connectSlotsByName(HealthAssessmentWidget);
    } // setupUi

    void retranslateUi(QWidget *HealthAssessmentWidget)
    {
        HealthAssessmentWidget->setWindowTitle(QApplication::translate("HealthAssessmentWidget", "Form", Q_NULLPTR));
        titleLabel->setText(QApplication::translate("HealthAssessmentWidget", "\345\201\245\345\272\267\350\257\204\344\274\260", Q_NULLPTR));
        cmLabel->setText(QApplication::translate("HealthAssessmentWidget", "\350\272\253\351\253\230 (cm):", Q_NULLPTR));
        kgLabel->setText(QApplication::translate("HealthAssessmentWidget", "\344\275\223\351\207\215 (kg):", Q_NULLPTR));
        Label->setText(QApplication::translate("HealthAssessmentWidget", "\346\224\266\347\274\251\345\216\213:", Q_NULLPTR));
        Label_2->setText(QApplication::translate("HealthAssessmentWidget", "\350\210\222\345\274\240\345\216\213:", Q_NULLPTR));
        Label_3->setText(QApplication::translate("HealthAssessmentWidget", "\345\277\203\347\216\207 (\346\254\241/\345\210\206):", Q_NULLPTR));
        assessButton->setText(QApplication::translate("HealthAssessmentWidget", "\345\274\200\345\247\213\350\257\204\344\274\260", Q_NULLPTR));
        resetButton->setText(QApplication::translate("HealthAssessmentWidget", "\351\207\215\347\275\256", Q_NULLPTR));
        resultTextEdit->setPlaceholderText(QApplication::translate("HealthAssessmentWidget", "\350\257\204\344\274\260\347\273\223\346\236\234\345\260\206\346\230\276\347\244\272\345\234\250\350\277\231\351\207\214", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class HealthAssessmentWidget: public Ui_HealthAssessmentWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HEALTHASSESSMENTWIDGET_H
