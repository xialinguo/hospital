#include "medicalhistorywidget.h"
#include "ui_medicalhistorywidget.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDebug>
#include <QDateTime>
MedicalHistoryWidget::MedicalHistoryWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MedicalHistoryWidget)
{
    ui->setupUi(this);
    setWindowTitle("我的就诊记录");
    loadDoctorList();
}

MedicalHistoryWidget::~MedicalHistoryWidget()
{
    delete ui;
}

void MedicalHistoryWidget::loadInitialData(const QString &studentId)
{
    m_currentStudentId = studentId;
    if (m_currentStudentId.isEmpty()) {
        qDebug() << "错误：学生ID为空，无法加载病历。";
        return;
    }
    refreshHistoryList();
    // 清空上一次的输入
    ui->complaintTextEdit->clear();
    ui->doctorComboBox->setCurrentIndex(0);
    ui->detailBrowser->clear();
    ui->historyListWidget->setCurrentRow(-1);
}

void MedicalHistoryWidget::loadDoctorList()
{
    ui->doctorComboBox->clear();
    ui->doctorComboBox->addItem("请选择医生...", QVariant(-1)); // 添加一个无效的默认项

    QSqlQuery query("SELECT doctor_id, name, department FROM doctor_info ORDER BY department, name");
    if (!query.exec()) {
        qDebug() << "加载医生列表失败:" << query.lastError().text();
        return;
    }

    while (query.next()) {
        QString doctorId = query.value("doctor_id").toString();
        QString name = query.value("name").toString();
        QString department = query.value("department").toString();
        QString displayText = QString("%1 (%2)").arg(name, department);
        ui->doctorComboBox->addItem(displayText, doctorId); // 显示文本和ID数据关联
    }
}

void MedicalHistoryWidget::refreshHistoryList()
{
    ui->historyListWidget->clear();

    QSqlQuery query;
    // 使用 LEFT JOIN 以确保即使医生信息被删除，病历依然能显示
    query.prepare("SELECT mo.issue_time, mo.chief_complaint, mo.diagnosis_result, mo.prescription_advice, IFNULL(di.name, '未知医生') AS doctor_name "
                  "FROM medical_order mo "
                  "LEFT JOIN doctor_info di ON mo.doctor_id = di.doctor_id "
                  "WHERE mo.student_id = :studentId "
                  "ORDER BY mo.issue_time DESC");
    query.bindValue(":studentId", m_currentStudentId.toInt());

    if (!query.exec()) {
        qDebug() << "加载历史病历失败:" << query.lastError().text();
        return;
    }

    while (query.next()) {
        QString time = query.value("issue_time").toDateTime().toString("yyyy-MM-dd hh:mm");
        QString doctorName = query.value("doctor_name").toString();
        QString diagnosis = query.value("diagnosis_result").toString();
        QString status = diagnosis.isEmpty() ? "待诊断" : "已完成";

        // 创建列表项
        QString itemText = QString("%1 | %2 | %3").arg(time, doctorName, status);
        QListWidgetItem *item = new QListWidgetItem(itemText);

        // 使用 setData 将所有需要的数据附加到 item 上，避免重复查询
        item->setData(Qt::UserRole, query.value("chief_complaint"));
        item->setData(Qt::UserRole + 1, diagnosis);
        item->setData(Qt::UserRole + 2, query.value("prescription_advice"));
        item->setData(Qt::UserRole + 3, doctorName);
        item->setData(Qt::UserRole + 4, time);

        // 根据状态设置颜色
        if (status == "待诊断") {
            item->setForeground(QBrush(QColor(255, 165, 0))); // 橙色
        } else {
            item->setForeground(QBrush(QColor(0, 128, 0)));   // 绿色
        }

        ui->historyListWidget->addItem(item);
    }
}


void MedicalHistoryWidget::on_historyListWidget_itemClicked(QListWidgetItem *item)
{
    if (!item) return;

    // 从 item 中直接读取我们之前存好的数据
    QString complaint = item->data(Qt::UserRole).toString();
    QString diagnosis = item->data(Qt::UserRole + 1).toString();
    QString advice = item->data(Qt::UserRole + 2).toString();
    QString doctorName = item->data(Qt::UserRole + 3).toString();
    QString time = item->data(Qt::UserRole + 4).toString();

    // 美化空值显示
    if (diagnosis.isEmpty()) diagnosis = "<i style='color:#999;'>等待医生填写...</i>";
    if (advice.isEmpty()) advice = "<i style='color:#999;'>等待医生填写...</i>";

    // 使用HTML格式化显示
    QString html = QString(
        "<h3>就诊详情</h3>"
        "<p><b>时间:</b> %1</p>"
        "<p><b>医生:</b> %2</p>"
        "<hr>"
        "<p><b>我的主诉:</b><br>%3</p>"
        "<p><b>医生诊断:</b><br>%4</p>"
        "<p><b>医嘱/处方:</b><br>%5</p>"
    ).arg(time, doctorName, complaint, diagnosis, advice);

    ui->detailBrowser->setHtml(html);
}


void MedicalHistoryWidget::on_submitButton_clicked()
{
    QString complaint = ui->complaintTextEdit->toPlainText().trimmed();
    int selectedDoctorIndex = ui->doctorComboBox->currentIndex();
    QString doctorId = ui->doctorComboBox->itemData(selectedDoctorIndex).toString();

    if (selectedDoctorIndex <= 0) {
        QMessageBox::warning(this, "信息不完整", "请选择一位医生。");
        return;
    }
    if (complaint.isEmpty()) {
        QMessageBox::warning(this, "信息不完整", "请填写您的病情主诉。");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO medical_order (student_id, doctor_id, chief_complaint, issue_time) "
                  "VALUES (:sid, :did, :complaint, NOW())");
    query.bindValue(":sid", m_currentStudentId.toInt());
    query.bindValue(":did", doctorId.toInt());
    query.bindValue(":complaint", complaint);

    if (!query.exec()) {
        QMessageBox::critical(this, "提交失败", "数据库错误，提交问诊失败: " + query.lastError().text());
        return;
    }

    QMessageBox::information(this, "提交成功", "您的问诊请求已成功提交！请留意历史记录中的状态更新。");

    // 提交成功后，清空输入框并刷新列表
    ui->complaintTextEdit->clear();
    ui->doctorComboBox->setCurrentIndex(0);
    refreshHistoryList();
}

void MedicalHistoryWidget::on_backButton_clicked()
{
    emit backToMenuRequested();
}
