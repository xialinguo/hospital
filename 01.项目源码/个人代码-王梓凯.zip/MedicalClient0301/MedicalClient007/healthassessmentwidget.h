#ifndef HEALTHASSESSMENTWIDGET_H
#define HEALTHASSESSMENTWIDGET_H

#include <QWidget>
#include "ui_healthassessmentwidget.h"  // 直接包含UI头文件

class HealthAssessmentWidget : public QWidget
{
    Q_OBJECT

public:
    explicit HealthAssessmentWidget(QWidget *parent = nullptr);
    ~HealthAssessmentWidget();

private slots:
    void on_assessButton_clicked();
    void on_resetButton_clicked();

private:
    Ui::HealthAssessmentWidget *ui;
    void calculateAssessment();
    QString getBMICategory(double bmi);
    QString getBPCategory(int systolic, int diastolic);
    QString getHeartRateCategory(int heartRate);
};

#endif // HEALTHASSESSMENTWIDGET_H
