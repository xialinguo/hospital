#include "patientwindow.h"
#include "ui_patientwindow.h"
#include "global.h"
#include <QMessageBox>
#include <QDebug>

PatientWindow::PatientWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::PatientWindow)
{
    ui->setupUi(this);
    setWindowTitle("智慧医疗管理系统 - 患者端");
    setMinimumSize(800, 600);

    clearExistingPages();

    // 创建所有功能页面
    appointmentWidget = new AppointmentWidget(this);
    chatWidget = new ChatWidget(this);
    healthAssessmentWidget = new HealthAssessmentWidget(this);
    // 【核心修改】创建新的三合一病历页面
    m_medicalHistoryWidget = new MedicalHistoryWidget(this);

    // 添加到 stackedWidget
    ui->stackedWidget->addWidget(appointmentWidget);
    ui->stackedWidget->addWidget(chatWidget);
    ui->stackedWidget->addWidget(healthAssessmentWidget);
    // 【核心修改】将新的病历页面添加到 stackedWidget
    ui->stackedWidget->addWidget(m_medicalHistoryWidget);

    // 【核心修改】移除不再需要的 doctorSelectionWidget 相关的 connect 和逻辑

    // 默认显示第一个页面 (预约挂号)
    ui->stackedWidget->setCurrentWidget(appointmentWidget);
}

PatientWindow::~PatientWindow()
{
    delete ui;
}

void PatientWindow::clearExistingPages()
{
    while (ui->stackedWidget->count() > 0) {
        QWidget* widget = ui->stackedWidget->widget(0);
        ui->stackedWidget->removeWidget(widget);
        widget->deleteLater();
    }
}

// 【核心修改】实现新按钮 "我的病历" 的点击事件
void PatientWindow::on_medicalHistoryButton_clicked()
{
    // 在显示病历页面前，传入当前登录的学生ID来加载数据
    m_medicalHistoryWidget->loadInitialData(QString::number(g_studentId));
    ui->stackedWidget->setCurrentWidget(m_medicalHistoryWidget);
}

void PatientWindow::on_appointmentButton_clicked()
{
    ui->stackedWidget->setCurrentWidget(appointmentWidget);
}

void PatientWindow::on_chatButton_clicked()
{
    ui->stackedWidget->setCurrentWidget(chatWidget);
}

void PatientWindow::on_healthAssessmentButton_clicked()
{
    ui->stackedWidget->setCurrentWidget(healthAssessmentWidget);
}

void PatientWindow::on_logoutButton_clicked()
{
    if (QMessageBox::question(this, "确认退出", "确定要退出登录吗？",
                              QMessageBox::Yes | QMessageBox::No) == QMessageBox::Yes)
    {
        this->close();
    }
}
