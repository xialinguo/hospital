#include "registerwindow.h"
#include "ui_registerwindow.h"
#include <QMessageBox>
#include <QRegularExpression>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>

RegisterWindow::RegisterWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RegisterWindow)
{
    ui->setupUi(this);

    setWindowTitle("用户注册");
    setFixedSize(500, 400);
    setWindowModality(Qt::ApplicationModal);

    ui->passwordEdit->setEchoMode(QLineEdit::Password);
    ui->confirmPasswordEdit->setEchoMode(QLineEdit::Password);
    ui->idCardEdit->setMaxLength(18);
    // 设置性别单选按钮的默认选择
        ui->maleRadioButton->setChecked(true);
}
void RegisterWindow::on_backToLoginButton_clicked()
{
    this->close();
}
RegisterWindow::~RegisterWindow()
{
    delete ui;
}

void RegisterWindow::on_registerConfirmButton_clicked()
{
    QString username = ui->usernameEdit->text().trimmed();
    QString password = ui->passwordEdit->text();
    QString confirmPassword = ui->confirmPasswordEdit->text();
    QString realName = ui->realNameEdit->text().trimmed();
    QString phone = ui->phoneEdit->text().trimmed();
    QString idCard = ui->idCardEdit->text().trimmed();
    QString gender = ui->maleRadioButton->isChecked() ? "男" : "女";

    // 基础校验（和你原来的一样）
    if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() ||
        realName.isEmpty() || phone.isEmpty() || idCard.isEmpty()) {
        QMessageBox::warning(this, "警告", "所有字段都必须填写");
        return;
    }
    if (password != confirmPassword) {
        QMessageBox::warning(this, "警告", "两次输入的密码不一致");
        return;
    }
    if (password.length() < 6) {
        QMessageBox::warning(this, "警告", "密码长度不能少于6位");
        return;
    }
    QRegularExpression phoneRegex("^1[3-9]\\d{9}$");
    if (!phoneRegex.match(phone).hasMatch()) {
        QMessageBox::warning(this, "警告", "请输入有效的手机号码");
        return;
    }
    QRegularExpression idCardRegex("^[1-9]\\d{5}(18|19|20)\\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\\d|3[01])\\d{3}[0-9Xx]$");
    if (!idCardRegex.match(idCard).hasMatch()) {
        QMessageBox::warning(this, "警告", "请输入有效的身份证号码");
        return;
    }

    // ==== 数据库插入 ====
    // ==== 数据库插入（按你的表结构） ====
    QSqlDatabase db = QSqlDatabase::database();  // 使用默认连接（确保程序启动时已连接好）
    if (!db.isOpen()) {
        QMessageBox::critical(this, "错误", "数据库未连接！");
        return;
    }

    // 1) 检查 name / phone / id_card 是否已占用（都是 UNIQUE）
    {
        QSqlQuery chk(db);

        // name（用“用户名”字段来写入 name 列）
        chk.prepare("SELECT COUNT(*) FROM student_info WHERE name = :name");
        chk.bindValue(":name", username);
        if (!chk.exec() || !chk.next()) {
            QMessageBox::critical(this, "错误", "检查用户名失败：" + chk.lastError().text());
            return;
        }
        if (chk.value(0).toInt() > 0) {
            QMessageBox::warning(this, "重复", "该用户名已存在，请更换用户名");
            return;
        }

        // phone
        chk.prepare("SELECT COUNT(*) FROM student_info WHERE phone = :phone");
        chk.bindValue(":phone", phone);
        if (!chk.exec() || !chk.next()) {
            QMessageBox::critical(this, "错误", "检查手机号失败：" + chk.lastError().text());
            return;
        }
        if (chk.value(0).toInt() > 0) {
            QMessageBox::warning(this, "重复", "该手机号已被使用");
            return;
        }

        // id_card
        chk.prepare("SELECT COUNT(*) FROM student_info WHERE id_card = :id");
        chk.bindValue(":id", idCard);
        if (!chk.exec() || !chk.next()) {
            QMessageBox::critical(this, "错误", "检查身份证失败：" + chk.lastError().text());
            return;
        }
        if (chk.value(0).toInt() > 0) {
            QMessageBox::warning(this, "重复", "该身份证号已被使用");
            return;
        }
    }

    // 2) 生成新的 student_id（因为不是 AUTO_INCREMENT）
    int newStudentId = 0;
    {
        QSqlQuery qid(db);
        if (!qid.exec("SELECT IFNULL(MAX(student_id), 0) + 1 FROM student_info") || !qid.next()) {
            QMessageBox::critical(this, "错误", "生成学号失败：" + qid.lastError().text());
            return;
        }
        newStudentId = qid.value(0).toInt();
        if (newStudentId <= 0) {
            QMessageBox::critical(this, "错误", "生成学号无效");
            return;
        }
    }

    // 3) 执行插入（只写入存在于表的列：student_id, name, pssword, phone, id_card）
    {
        QSqlQuery ins(db);
        ins.prepare(
            "INSERT INTO student_info (student_id, name, pssword, phone, id_card) "
            "VALUES (:sid, :name, :pwd, :phone, :idcard)"
        );
        ins.bindValue(":sid",   username);
        ins.bindValue(":name",  realName);   // 用“用户名”填到 name 列
        ins.bindValue(":pwd",   password);   // 注意列名是 pssword
        ins.bindValue(":phone", phone);
        ins.bindValue(":idcard", idCard);
        ins.bindValue(":gender", gender);  //性别

        if (!ins.exec()) {
            // 处理重复键等常见错误
            const QString err = ins.lastError().text();
            QMessageBox::critical(this, "注册失败", "数据库插入失败：" + err);
            return;
        }
    }

    // 4) 给用户提示（保持你原有提示格式）
    QMessageBox::information(this, "成功",
            QString("注册成功！\n用户名: %1\n姓名: %2\n性别: %3").arg(username).arg(realName).arg(gender));

    // 清空输入框（保持你原有逻辑）
    ui->usernameEdit->clear();
    ui->passwordEdit->clear();
    ui->confirmPasswordEdit->clear();
    ui->realNameEdit->clear();
    ui->phoneEdit->clear();
    ui->idCardEdit->clear();
    ui->maleRadioButton->setChecked(true); // 重置性别选择


}
