#ifndef DATABASEMANAGER_H
#define DATABASEMANAGER_H



#include <QObject>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

class DatabaseManager : public QObject
{
    Q_OBJECT
public:
    explicit DatabaseManager(QObject *parent = nullptr);
    ~DatabaseManager();

    bool connect(const QString &host,
                 const QString &dbName,
                 const QString &user,
                 const QString &password,
                 int port = 3306);

    void disconnect();

    bool execute(const QString &sql);
    QSqlDatabase& getDatabase() { return db; }


private:
    QSqlDatabase db;
};

#endif // DATABASEMANAGER_H
