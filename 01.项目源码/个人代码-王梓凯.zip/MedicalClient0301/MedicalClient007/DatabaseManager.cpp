#include "DatabaseManager.h"

DatabaseManager::DatabaseManager(QObject *parent)
    : QObject(parent)
{
}

DatabaseManager::~DatabaseManager()
{
    disconnect();  // 析构时释放资源
}

bool DatabaseManager::connect(const QString &host,
                              const QString &dbName,
                              const QString &user,
                              const QString &password,
                              int port)
{
    // 先释放之前的连接（避免重复对象）
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        QSqlDatabase::removeDatabase("qt_sql_default_connection");
    }

    db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(host);
    db.setDatabaseName(dbName);
    db.setUserName(user);
    db.setPassword(password);
    db.setPort(port);

    if (!db.open()) {
        qDebug() << "数据库连接失败:" << db.lastError().text();
        return false;
    }

    qDebug() << "数据库连接成功!";
    return true;
}

void DatabaseManager::disconnect()
{
    if (db.isOpen()) {
        db.close();
        qDebug() << "数据库连接已关闭";
    }
}

bool DatabaseManager::execute(const QString &sql)
{
    if (!db.isOpen()) {
        qDebug() << "数据库未连接，无法执行SQL";
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(sql)) {
        qDebug() << "SQL执行失败:" << query.lastError().text();
        return false;
    }
    qDebug() << "SQL执行成功:" << sql;
    return true;
}
