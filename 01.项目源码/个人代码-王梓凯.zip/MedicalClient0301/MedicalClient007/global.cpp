#include "global.h"

int g_studentId = 0;  // 定义全局变量并初始化
