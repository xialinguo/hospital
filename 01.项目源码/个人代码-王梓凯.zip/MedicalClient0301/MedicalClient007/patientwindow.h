#ifndef PATIENTWINDOW_H
#define PATIENTWINDOW_H

#include <QMainWindow>

#include "appointmentwidget.h"
#include "chatwidget.h"
#include "healthassessmentwidget.h"
#include "medicalhistorywidget.h" // <-- 【核心修改】包含新的头文件

namespace Ui {
class PatientWindow;
}

class PatientWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit PatientWindow(QWidget *parent = 0);
    ~PatientWindow();

private slots:
    void on_appointmentButton_clicked();
    void on_chatButton_clicked();
    void on_healthAssessmentButton_clicked();
    void on_logoutButton_clicked();

    // <-- 【核心修改】重命名按钮对应的槽函数
    void on_medicalHistoryButton_clicked();

private:
    void clearExistingPages();

    Ui::PatientWindow *ui;

    AppointmentWidget *appointmentWidget;
    ChatWidget *chatWidget;
    HealthAssessmentWidget *healthAssessmentWidget;

    // <-- 【核心修改】添加新的控件指针，并移除不再需要的旧指针
    MedicalHistoryWidget *m_medicalHistoryWidget;
};

#endif // PATIENTWINDOW_H
