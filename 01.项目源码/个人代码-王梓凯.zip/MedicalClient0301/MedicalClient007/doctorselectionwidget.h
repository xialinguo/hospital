#ifndef DOCTORSELECTIONWIDGET_H
#define DOCTORSELECTIONWIDGET_H

#include <QWidget>
#include <QtSql>

// 前向声明，避免循环包含
class DiagnosisWidget;

namespace Ui {
class DoctorSelectionWidget;
}

class DoctorSelectionWidget : public QWidget
{
    Q_OBJECT

public:
    explicit DoctorSelectionWidget(QWidget *parent = nullptr);
    ~DoctorSelectionWidget();

// 添加 signals 部分
signals:
    // 当医生被选择后，发射此信号，并带上医生的ID
    void doctorSelected(int doctorId);

private slots:
    void on_selectButton_clicked();

private:
    void setupDatabaseConnection();
    void loadDoctors();

    Ui::DoctorSelectionWidget *ui;
    QSqlDatabase m_db;
    // 不再需要持有 DiagnosisWidget 的指针
    // DiagnosisWidget *m_diagnosisWidget;
};

#endif // DOCTORSELECTIONWIDGET_H
