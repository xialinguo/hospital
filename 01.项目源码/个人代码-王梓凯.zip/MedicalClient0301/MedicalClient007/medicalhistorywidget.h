#ifndef MEDICALHISTORYWIDGET_H
#define MEDICALHISTORYWIDGET_H

#include <QWidget>
#include <QListWidgetItem>

namespace Ui {
class MedicalHistoryWidget;
}

class MedicalHistoryWidget : public QWidget
{
    Q_OBJECT

public:
    explicit MedicalHistoryWidget(QWidget *parent = nullptr);
    ~MedicalHistoryWidget();

    // 当切换到此界面时，主窗口调用此函数加载数据
    void loadInitialData(const QString &studentId);

signals:
    void backToMenuRequested();

private slots:
    // 当点击左侧历史记录列表时，在右侧显示详情
    void on_historyListWidget_itemClicked(QListWidgetItem *item);

    // 当点击“提交”按钮时，发起新的问诊
    void on_submitButton_clicked();

    // 返回主菜单
    void on_backButton_clicked();

private:
    Ui::MedicalHistoryWidget *ui;
    QString m_currentStudentId;

    // 从数据库加载医生列表到下拉框
    void loadDoctorList();
    // 刷新左侧的病历列表
    void refreshHistoryList();
};

#endif // MEDICALHISTORYWIDGET_H
