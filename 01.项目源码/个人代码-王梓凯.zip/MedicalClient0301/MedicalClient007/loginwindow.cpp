#include "loginwindow.h"
#include "ui_loginwindow.h"
#include "registerwindow.h"
#include "patientwindow.h"
#include "DatabaseManager.h"
#include <QMessageBox>
#include <QtSql>
#include "global.h"

extern DatabaseManager g_dbManager;

static PatientWindow *patientWindowInstance = nullptr;

LoginWindow::LoginWindow(QWidget *parent)
    : QMainWindow(parent),
      ui(new Ui::LoginWindow),
      registerWindow(nullptr)
{
    ui->setupUi(this);
    setWindowTitle("智慧医疗管理系统 - 登录");
}

LoginWindow::~LoginWindow()
{
    delete ui;
    if (registerWindow) delete registerWindow;
}

void LoginWindow::on_loginButton_clicked()
{
    QString student_id_str = ui->usernameEdit->text().trimmed();
    QString password = ui->passwordEdit->text().trimmed();

    if (student_id_str.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "警告", "用户名或密码不能为空");
        return;
    }

    QSqlQuery query(QSqlDatabase::database("qt_sql_default_connection"));
    // 【核心修改】查询的列名应为 pssword，并且应该用 student_id 作为用户名
    query.prepare("SELECT student_id FROM student_info WHERE student_id = :sid AND pssword = :password");
    query.bindValue(":sid", student_id_str.toInt()); // 假设学号是数字
    query.bindValue(":password", password);

    if (query.exec() && query.next()) {
        // 【核心修改】在查询成功后，再从结果中获取 student_id 并赋值给全局变量
        g_studentId = query.value(0).toInt();

        QMessageBox::information(this, "登录成功", "学生登录成功！");
        this->hide();

        if (!patientWindowInstance) {
            patientWindowInstance = new PatientWindow();
            connect(patientWindowInstance, &QObject::destroyed, [this]() {
                patientWindowInstance = nullptr;
                this->show();
            });
        }
        patientWindowInstance->show();
        patientWindowInstance->activateWindow();
    } else {
        QMessageBox::warning(this, "登录失败", "学号或密码错误");
    }
}

void LoginWindow::on_registerButton_clicked()
{
    if (!registerWindow) {
        registerWindow = new RegisterWindow();
    }
    registerWindow->show();
}
