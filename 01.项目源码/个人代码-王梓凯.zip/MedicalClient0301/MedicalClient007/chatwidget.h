#ifndef CHATWIDGET_H
#define CHATWIDGET_H

#include <QWidget>
#include <QMap>
#include <QTcpSocket>
#include <QAbstractSocket>

namespace Ui {
class ChatWidget;
}

class ChatWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ChatWidget(QWidget *parent = nullptr);
    ~ChatWidget();

    void loadDoctorList();  // 加载医生列表

signals:
    void backToMenuRequested();

protected:
    void showEvent(QShowEvent *event) override;

private slots:
    void on_sendButton_clicked();
    void on_doctorComboBox_currentIndexChanged(int index);

    void onConnected();
    void onDisconnected();
    void onReadyRead();
    void displayError(QAbstractSocket::SocketError socketError);

private:
    Ui::ChatWidget *ui;

    QString m_currentDoctorId;
    QTcpSocket *m_socket;
    bool m_isFirstShow = true;

    void connectToServer();
    void updateUIState();
    void registerWithServer();
};

#endif // CHATWIDGET_H
