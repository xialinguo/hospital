#include "diagnosiswidget.h"
#include "ui_diagnosiswidget.h"
#include <QMessageBox>
#include <QDebug>
#include <QSqlError>
#include "global.h"

DiagnosisWidget::DiagnosisWidget(int doctorId, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DiagnosisWidget),
    m_doctorId(doctorId),
    m_orderId(-1)
{
    ui->setupUi(this);
    setWindowTitle("诊断与医嘱");

    // 设置UI样式
    ui->diagnosisResultEdit->setReadOnly(true);
    ui->prescriptionEdit->setReadOnly(true);
    ui->diagnosisResultEdit->setStyleSheet("background-color: #f5f5f5;");
    ui->prescriptionEdit->setStyleSheet("background-color: #f5f5f5;");

    // 连接数据库并创建新的问诊记录
    setupDatabaseConnection();
    // [核心修改] 函数调用变更
    createNewOrder();
}

DiagnosisWidget::~DiagnosisWidget()
{
    if (m_db.isOpen()) {
        m_db.close();
    }
    delete ui;
}

void DiagnosisWidget::setupDatabaseConnection()
{
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        m_db = QSqlDatabase::database("qt_sql_default_connection");
    } else {
        m_db = QSqlDatabase::addDatabase("QMYSQL");
        m_db.setHostName("127.0.0.1");
        m_db.setPort(3306);
        m_db.setDatabaseName("your_db_name"); // 替换成您的数据库名
        m_db.setUserName("your_username");   // 替换成您的用户名
        m_db.setPassword("your_password");   // 替换成您的密码
    }
    if (!m_db.open()) {
        QMessageBox::critical(this, "数据库错误", "无法连接到数据库: " + m_db.lastError().text());
    }
}

// ======================= [核心修改] =======================
//  新的 createNewOrder 函数，每次都无条件创建新纪录
// ========================================================
void DiagnosisWidget::createNewOrder()
{
    if (!m_db.isOpen()) {
        QMessageBox::critical(this, "错误", "数据库未连接，无法开始问诊！");
        return;
    }

    qDebug() << "为本次新问诊创建记录...";
    QSqlQuery insertQuery(m_db);
    insertQuery.prepare("INSERT INTO medical_order (student_id, doctor_id, issue_time) VALUES (:sid, :did, NOW())");
    insertQuery.bindValue(":sid", g_studentId);
    insertQuery.bindValue(":did", m_doctorId);

    if (insertQuery.exec()) {
        m_orderId = insertQuery.lastInsertId().toInt();
        // 清空界面所有内容，确保是全新的开始
        ui->chiefComplaintEdit->clear();
        ui->diagnosisResultEdit->clear();
        ui->prescriptionEdit->clear();
        // 确保主诉框是可编辑的
        ui->chiefComplaintEdit->setReadOnly(false);
        ui->chiefComplaintEdit->setStyleSheet(""); // 恢复默认样式
        qDebug() << "新问诊记录创建成功，order_id:" << m_orderId;
    } else {
        QMessageBox::critical(this, "数据库错误", "创建新的医嘱记录失败: " + insertQuery.lastError().text());
        m_orderId = -1; // 创建失败，ID设为无效
    }
}

void DiagnosisWidget::on_submitButton_clicked()
{
    QString chiefComplaint = ui->chiefComplaintEdit->toPlainText().trimmed();

    if (chiefComplaint.isEmpty()) {
        QMessageBox::warning(this, "提示", "请填写主诉内容！");
        return;
    }

    if (m_orderId == -1) {
        QMessageBox::critical(this, "错误", "没有有效的医嘱记录，无法提交！可能是记录创建失败。");
        return;
    }

    if (!m_db.isOpen()) {
        QMessageBox::critical(this, "数据库错误", "数据库未连接，无法提交！");
        return;
    }

    QSqlQuery query(m_db);
    // 更新主诉内容，同时更新 issue_time，确保医生端能正确排序
    query.prepare("UPDATE medical_order SET chief_complaint = :complaint, issue_time = NOW() WHERE order_id = :oid");
    query.bindValue(":complaint", chiefComplaint);
    query.bindValue(":oid", m_orderId);

    if (query.exec()) {
        QMessageBox::information(this, "提交成功", "您的主诉已提交，请等待医生诊断");
        // 提交成功后，将主诉框设为只读，防止重复提交
        ui->chiefComplaintEdit->setReadOnly(true);
        ui->chiefComplaintEdit->setStyleSheet("background-color: #f5f5f5;");
    } else {
        QMessageBox::critical(this, "提交失败", "主诉提交失败: " + query.lastError().text());
    }
}

void DiagnosisWidget::on_clearButton_clicked()
{
    // 增加判断，如果已提交（只读），则不能清空
    if (ui->chiefComplaintEdit->isReadOnly()) {
        QMessageBox::information(this, "提示", "主诉已提交，无法清空。");
        return;
    }
    ui->chiefComplaintEdit->clear();
}
