#include "personalinfodialog.h"
#include "ui_personalinfodialog.h"
#include <QPixmap>
#include <QtSql/QSqlQuery>
#include <QtSql/QSqlError>
#include <QDebug>

PersonalInfoDialog::PersonalInfoDialog(const QString &doctorId, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PersonalInfoDialog),
    m_doctorId(doctorId)
{
    ui->setupUi(this);
    setWindowTitle("医生信息");

    QString styleSheet = R"(
        QDialog#PersonalInfoDialog { background-color: #F2F2F2; }
        QFrame#headerFrame { background-color: rgb(0, 108, 57); border-bottom-left-radius: 15px; border-bottom-right-radius: 15px; }
        QLabel#titleLabel { font-size: 24px; font-weight: bold; color: white; }
        QFrame#infoFrame { background-color: white; border-radius: 15px; border: 1px solid #DDDDDD; }
        QLabel[objectName$="Title"] { font-weight: bold; color: rgb(161, 63, 11); font-size: 14px; padding-right: 10px; }
        QLabel[objectName$="Title"] + QLabel { color: rgb(63, 63, 63); font-size: 14px; }
        QDialogButtonBox QPushButton { background-color: rgb(162, 162, 162); color: white; border: none; border-radius: 5px; font-size: 14px; font-weight: bold; padding: 8px 24px; }
        QDialogButtonBox QPushButton:hover { background-color: rgb(180, 180, 180); }
        QDialogButtonBox QPushButton:pressed { background-color: rgb(150, 150, 150); }
    )";
    this->setStyleSheet(styleSheet);

    loadDoctorInfo();
}

PersonalInfoDialog::~PersonalInfoDialog()
{
    delete ui;
}

void PersonalInfoDialog::loadDoctorInfo()
{
    QSqlQuery query;
    query.prepare("SELECT name, gender, department, title, phone FROM doctor_info WHERE doctor_id = :id");
    query.bindValue(":id", m_doctorId);

    if(query.exec() && query.next()) {
        ui->labelId->setText(m_doctorId);
        ui->labelName->setText(query.value("name").toString());
        ui->labelGender->setText(query.value("gender").toString());
        ui->labelDepartment->setText(query.value("department").toString());
        ui->labelPosition->setText(query.value("title").toString());
        ui->labelPhone->setText(query.value("phone").toString());
    } else {
        qDebug() << "Failed to load doctor info:" << query.lastError().text();
        ui->labelId->setText(m_doctorId);
        ui->labelName->setText("加载失败");
        ui->labelGender->setText("加载失败");
        ui->labelDepartment->setText("加载失败");
        ui->labelPosition->setText("加载失败");
        ui->labelPhone->setText("加载失败");
    }
}
