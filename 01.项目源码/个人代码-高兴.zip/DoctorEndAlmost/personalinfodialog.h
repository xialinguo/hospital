#ifndef PERSONALINFODIALOG_H
#define PERSONALINFODIALOG_H

#include <QDialog>

namespace Ui {
class PersonalInfoDialog;
}

class PersonalInfoDialog : public QDialog
{
    Q_OBJECT

public:
    explicit PersonalInfoDialog(const QString &doctorId, QWidget *parent = nullptr);
    ~PersonalInfoDialog();

private:
    Ui::PersonalInfoDialog *ui;
    QString m_doctorId;
    void loadDoctorInfo();
};

#endif // PERSONALINFODIALOG_H
