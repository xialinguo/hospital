#include "logindialog.h"
#include "ui_logindialog.h"
#include "registerdialog.h" // 只包含头文件 .h
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QPixmap>

// ！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
// ！！！！！！ 确保这里没有 #include "registerdialog.cpp" ！！！！！！
// ！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！

LoginDialog::LoginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDialog)
{
    ui->setupUi(this);
    setWindowTitle("医生端登录");

    ui->bannerFrame->setStyleSheet(
        "QFrame#bannerFrame {"
        "  border-image: url(:/images/doctor_avatar.png) 0 0 0 0 stretch stretch;"
        "  border: none;"
        "}"
    );
}

LoginDialog::~LoginDialog()
{
    delete ui;
}

QString LoginDialog::loggedInDoctorId() const
{
    return m_loggedInDoctorId;
}

void LoginDialog::on_loginButton_clicked()
{
    QString doctorIdStr = ui->idLineEdit->text();
    QString password = ui->passwordLineEdit->text();

    if (doctorIdStr.isEmpty() || password.isEmpty()) {
        QMessageBox::warning(this, "登录失败", "请输入工号和密码！");
        return;
    }

    QSqlQuery query;
    query.prepare("SELECT password FROM doctor_info WHERE doctor_id = :id");
    query.bindValue(":id", doctorIdStr);

    if (!query.exec()) {
        QMessageBox::critical(this, "数据库错误", query.lastError().text());
        return;
    }

    if (query.next()) {
        QString dbPassword = query.value(0).toString();
        if (password == dbPassword) {
            m_loggedInDoctorId = doctorIdStr;
            accept();
        } else {
            QMessageBox::warning(this, "登录失败", "工号或密码错误！");
        }
    } else {
        QMessageBox::warning(this, "登录失败", "工号不存在！");
    }
}

void LoginDialog::on_registerButton_clicked()
{
    RegisterDialog regDialog(this);
    regDialog.exec();
}
