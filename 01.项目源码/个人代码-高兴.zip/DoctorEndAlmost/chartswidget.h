#ifndef CHARTSWIDGET_H
#define CHARTSWIDGET_H

#include <QWidget>
#include <QtCharts>
#include <QList>

QT_CHARTS_USE_NAMESPACE

struct PatientData {
    double height;
    double weight;
    int high_blood;
    int low_blood;
};

namespace Ui {
class ChartsWidget;
}

class ChartsWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ChartsWidget(QWidget *parent = nullptr);
    ~ChartsWidget();

signals:
    void backToMenuRequested();

private slots:
    void on_backButton_clicked();

private:
    Ui::ChartsWidget *ui;
    void setupBmiScatterChart(const QList<PatientData> &patientList);
    void setupBloodPressureTable(const QList<PatientData> &patientList);
    void loadData();
};

#endif // CHARTSWIDGET_H
