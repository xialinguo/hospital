#include "mainwindow.h"
#include "logindialog.h"
#include <QApplication>
#include <QSqlDatabase>
#include <QSqlError>
#include <QMessageBox>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName("60.205.162.162");
    db.setPort(3306);
    db.setDatabaseName("smart_medical");
    db.setUserName("student");
    db.setPassword("your_password");

    if (!db.open()) {
        QMessageBox::critical(nullptr, "数据库连接失败", db.lastError().text());
        return -1;
    }

    LoginDialog loginDialog;
    if (loginDialog.exec() == QDialog::Accepted) {
        QString doctorId = loginDialog.loggedInDoctorId();
        MainWindow w(doctorId);
        w.show();
        return a.exec();
    } else {
        return 0;
    }
}
