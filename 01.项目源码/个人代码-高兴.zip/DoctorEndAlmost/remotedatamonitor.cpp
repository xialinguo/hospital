#include "remotedatamonitor.h"
#include "ui_remotedatamonitor.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QTime>
#include <QDebug>
#include <QGraphicsDropShadowEffect>
#include <QMessageBox>

RemoteDataMonitor::RemoteDataMonitor(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::RemoteDataMonitor)
{
    ui->setupUi(this);
    setWindowTitle("个人健康快照");
    this->setStyleSheet("background-color: palette(window);");

    QString cardStyle = "QFrame { background-color: white; border-radius: 15px; border: 2px solid #E0E0E0; }";
    ui->bmiCard->setStyleSheet(cardStyle);
    ui->bpCard->setStyleSheet(cardStyle);
    ui->hrCard->setStyleSheet(cardStyle);

    auto addShadow = [](QWidget* widget){
        auto shadow = new QGraphicsDropShadowEffect(widget);
        shadow->setBlurRadius(20);
        shadow->setColor(QColor(0, 0, 0, 80));
        shadow->setOffset(0, 5);
        widget->setGraphicsEffect(shadow);
    };
    addShadow(ui->bmiCard);
    addShadow(ui->bpCard);
    addShadow(ui->hrCard);
    clearDashboard();
}

RemoteDataMonitor::~RemoteDataMonitor()
{
    delete ui;
}

void RemoteDataMonitor::loadDataForDoctor(const QString &doctorId)
{
    loadPatientList(doctorId);
}

void RemoteDataMonitor::loadPatientList(const QString &doctorId)
{
    ui->patientComboBox->clear();
    m_patientMap.clear();
    ui->patientComboBox->addItem("请选择一位患者查看健康快照...");

    QSqlQuery query;
    QString sql = "SELECT DISTINCT s.student_id, s.name "
                  "FROM student_info AS s "
                  "JOIN appointment AS a ON s.student_id = a.student_id "
                  "WHERE a.doctor_id = :doctorId AND s.height IS NOT NULL "
                  "ORDER BY s.name";
    query.prepare(sql);
    query.bindValue(":doctorId", doctorId);

    if(query.exec()) {
        while(query.next()) {
            QString id = query.value("student_id").toString();
            QString name = query.value("name").toString();
            ui->patientComboBox->addItem(name);
            m_patientMap.insert(name, id);
        }
    } else {
        qDebug() << "Failed to load patient list for doctor: " << query.lastError().text();
    }
    clearDashboard();
}

void RemoteDataMonitor::on_patientComboBox_currentIndexChanged(int index)
{
    if (index <= 0) {
        clearDashboard();
        return;
    }

    QString currentName = ui->patientComboBox->currentText();
    QString studentId = m_patientMap.value(currentName);

    if (!studentId.isEmpty()) {
        updateDashboard(studentId);
    } else {
        clearDashboard();
    }
}

void RemoteDataMonitor::clearDashboard()
{
    ui->bmiChartView->setChart(createBmiChart(0));
    ui->bmiCategoryLabel->setText("请选择患者");
    ui->systolicLabel->setText("--");
    ui->diastolicLabel->setText("--");
    ui->bpCategoryLabel->setText("--");
    ui->hrValueLabel->setText("--");
    ui->hrCategoryLabel->setText("--");

    setCardStyle(ui->bmiCard, QColor("#E0E0E0"));
    setCardStyle(ui->bpCard, QColor("#E0E0E0"));
    setCardStyle(ui->hrCard, QColor("#E0E0E0"));
}

void RemoteDataMonitor::updateDashboard(const QString &studentId)
{
    QSqlQuery query;
    // 【关键修复】将查询的列名从 'age' 改为 'heartrating'
    query.prepare("SELECT height, weight, high_blood, low_blood, heartrating FROM student_info WHERE student_id = :id");
    query.bindValue(":id", studentId);

    if(!query.exec() || !query.next()) {
        qDebug() << "Failed to fetch data for student: " << studentId;
        clearDashboard();
        return;
    }

    double height = query.value("height").toDouble();
    double weight = query.value("weight").toDouble();
    double bmi = (height > 0) ? (weight / ((height / 100.0) * (height / 100.0))) : 0;

    ui->bmiChartView->setChart(createBmiChart(bmi));

    QString bmiCategory;
    QColor bmiColor;
    if (bmi < 18.5) { bmiCategory = "体重偏低"; bmiColor = QColor("#3498db"); }
    else if (bmi < 24) { bmiCategory = "正常范围"; bmiColor = QColor("#2ecc71"); }
    else if (bmi < 28) { bmiCategory = "超重"; bmiColor = QColor("#f1c40f"); }
    else { bmiCategory = "肥胖"; bmiColor = QColor("#e74c3c"); }
    ui->bmiCategoryLabel->setText(bmiCategory);
    setCardStyle(ui->bmiCard, bmiColor);

    int systolic = query.value("high_blood").toInt();
    int diastolic = query.value("low_blood").toInt();
    ui->systolicLabel->setText(QString::number(systolic));
    ui->diastolicLabel->setText(QString::number(diastolic));

    QString bpCategory;
    QColor bpColor;
    if (systolic > 180 || diastolic > 120) { bpCategory = "高血压危象"; bpColor = QColor("#c0392b"); }
    else if (systolic >= 140 || diastolic >= 90) { bpCategory = "高血压二期"; bpColor = QColor("#e74c3c"); }
    else if (systolic >= 130 || diastolic >= 80) { bpCategory = "高血压一期"; bpColor = QColor("#f39c12"); }
    else if (systolic >= 120 && diastolic < 80) { bpCategory = "血压偏高"; bpColor = QColor("#f1c40f"); }
    else { bpCategory = "正常血压"; bpColor = QColor("#2ecc71"); }
    ui->bpCategoryLabel->setText(bpCategory);
    setCardStyle(ui->bpCard, bpColor);

    // 【关键修复】从正确的 'heartrating' 列获取心率数据
    int heartRate = query.value("heartrating").toInt();
    ui->hrValueLabel->setText(QString::number(heartRate));

    QString hrCategory;
    QColor hrColor;
    if (heartRate > 100) { hrCategory = "心动过速"; hrColor = QColor("#e74c3c"); }
    else if (heartRate < 60) { hrCategory = "心动过缓"; hrColor = QColor("#f1c40f"); }
    else { hrCategory = "正常心率"; hrColor = QColor("#2ecc71"); }
    ui->hrCategoryLabel->setText(hrCategory);
    setCardStyle(ui->hrCard, hrColor);
}

QChart* RemoteDataMonitor::createBmiChart(double bmi)
{
    QPieSeries *series = new QPieSeries();
    series->setHoleSize(0.65);
    QPieSlice *valueSlice = series->append("", bmi > 40 ? 40 : bmi);
    valueSlice->setBrush(QColor(ui->bmiCategoryLabel->palette().color(QPalette::Text)));
    valueSlice->setBorderWidth(0);
    QPieSlice *backgroundSlice = series->append("", 40 - valueSlice->value());
    backgroundSlice->setBrush(QColor("#E0E0E0"));
    backgroundSlice->setBorderWidth(0);
    QChart *chart = new QChart();
    chart->addSeries(series);
    chart->legend()->hide();
    chart->setTitle(QString::number(bmi, 'f', 1));
    chart->setTitleFont(QFont("Arial", 24, QFont::Bold));
    chart->setAnimationOptions(QChart::SeriesAnimations);
    chart->setBackgroundRoundness(0);
    chart->setMargins(QMargins(0, 0, 0, 0));
    return chart;
}

void RemoteDataMonitor::setCardStyle(QFrame *card, const QColor &borderColor)
{
    card->setStyleSheet(QString("QFrame { background-color: white; border-radius: 15px; border: 3px solid %1; }").arg(borderColor.name()));
}

void RemoteDataMonitor::on_backButton_clicked()
{
    emit backToMenuRequested();
}
