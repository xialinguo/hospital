#include "chartswidget.h"
#include "ui_chartswidget.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QTime>
#include <QPen>
#include <QPainter>
#include <QDebug>
#include <QMap>
#include <QTableWidgetItem>

ChartsWidget::ChartsWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ChartsWidget)
{
    ui->setupUi(this);
    setWindowTitle("数据图表分析");
    this->setStyleSheet("background-color: palette(window);");

    QString standardsHtml = R"(
        <style>
            body { font-family: sans-serif; } h4 { color: #006C39; margin-bottom: 5px;}
            table { width: 100%; border-collapse: collapse; } td { padding: 4px; border: 1px solid #E0E0E0; }
            .level { font-weight: bold; color: #333; } .criteria { color: #555; }
        </style>
        <h4>血压分类标准 (ACC/AHA)</h4>
        <table>
            <tr><td class="level">正常</td><td class="criteria">&lt;120 / &lt;80 mmHg</td></tr>
            <tr><td class="level">偏高</td><td class="criteria">120-129 / &lt;80 mmHg</td></tr>
            <tr><td class="level">高血压一期</td><td class="criteria">130-139 / 80-89 mmHg</td></tr>
            <tr><td class="level">高血压二期</td><td class="criteria">&ge;140 / &ge;90 mmHg</td></tr>
            <tr><td class="level">高血压危象</td><td class="criteria">&gt;180 / &gt;120 mmHg</td></tr>
        </table>
    )";
    ui->standardsBrowser->setHtml(standardsHtml);
    ui->standardsBrowser->setFrameStyle(QFrame::NoFrame);

    ui->reminderLabel->setStyleSheet(
        "QLabel { color: #8A6D3B; background-color: #FFFBE6; border: 1px solid #FEEFB3; border-radius: 4px; padding: 5px 10px; }"
    );
    ui->reminderLabel->setVisible(false);

    loadData();
}

ChartsWidget::~ChartsWidget()
{
    delete ui;
}

void ChartsWidget::loadData()
{
    QList<PatientData> patientList;

    QSqlQuery query;
    if (query.exec("SELECT height, weight, high_blood, low_blood FROM student_info WHERE height IS NOT NULL AND weight IS NOT NULL")) {
        while (query.next()) {
            PatientData data;
            data.height = query.value("height").toDouble();
            data.weight = query.value("weight").toDouble();
            data.high_blood = query.value("high_blood").toInt();
            data.low_blood = query.value("low_blood").toInt();
            if (data.height > 100 && data.height < 250 && data.weight > 30) {
                 patientList.append(data);
            }
        }
    } else {
        qDebug() << "Failed to load chart data:" << query.lastError().text();
    }

    if (patientList.isEmpty()) {
        qDebug() << "Chart data query returned no data. Generating fake data.";
        ui->reminderLabel->setText("💡 提示: 数据库暂无记录，当前显示为随机生成的示例数据。");
        ui->reminderLabel->setVisible(true);
        qsrand(QTime::currentTime().msec());
        for (int i = 0; i < 100; ++i) {
            PatientData data;
            data.height = 155 + (qrand() % (190 - 155));
            double baseBmi = 17.0 + (qrand() % 150) / 10.0;
            data.weight = baseBmi * (data.height / 100.0) * (data.height / 100.0);
            data.high_blood = 100 + (qrand() % (160 - 100));
            data.low_blood = 60 + (qrand() % (100 - 60));
            patientList.append(data);
        }
    } else {
        ui->reminderLabel->setVisible(false);
    }

    setupBmiScatterChart(patientList);
    setupBloodPressureTable(patientList);
}

void ChartsWidget::setupBmiScatterChart(const QList<PatientData> &patientList)
{
    QChart *chart = new QChart();
    chart->setTitle("身高-体重分布 (BMI范围示意)");
    QScatterSeries *series = new QScatterSeries();
    series->setName("患者");
    series->setMarkerShape(QScatterSeries::MarkerShapeCircle);
    series->setMarkerSize(10.0);
    for (const auto& patient : patientList) { series->append(patient.height, patient.weight); }
    chart->addSeries(series);
    QValueAxis *axisX = new QValueAxis;
    axisX->setTitleText("身高 (cm)");
    axisX->setRange(140, 200);
    axisX->setTickCount(7);
    chart->addAxis(axisX, Qt::AlignBottom);
    series->attachAxis(axisX);
    QValueAxis *axisY = new QValueAxis;
    axisY->setTitleText("体重 (kg)");
    axisY->setRange(30, 130);
    chart->addAxis(axisY, Qt::AlignLeft);
    series->attachAxis(axisY);
    auto createBmiLimitSeries = [&](double bmi, const QColor &color) {
        QLineSeries *limitSeries = new QLineSeries();
        for (double h = 140; h <= 200; h += 2) {
            double h_m = h / 100.0;
            double w = bmi * h_m * h_m;
            limitSeries->append(h, w);
        }
        limitSeries->setColor(color);
        limitSeries->setName(QString("BMI = %1").arg(bmi));
        return limitSeries;
    };
    QLineSeries *bmi18_5 = createBmiLimitSeries(18.5, Qt::blue);
    QLineSeries *bmi24 = createBmiLimitSeries(24.0, Qt::green);
    QLineSeries *bmi28 = createBmiLimitSeries(28.0, Qt::darkYellow);
    chart->addSeries(bmi18_5); chart->addSeries(bmi24); chart->addSeries(bmi28);
    bmi18_5->attachAxis(axisX); bmi18_5->attachAxis(axisY);
    bmi24->attachAxis(axisX);   bmi24->attachAxis(axisY);
    bmi28->attachAxis(axisX);   bmi28->attachAxis(axisY);
    chart->legend()->setVisible(true);
    chart->legend()->setAlignment(Qt::AlignTop);
    ui->scatterChartView->setChart(chart);
    ui->scatterChartView->setRenderHint(QPainter::Antialiasing);
}

void ChartsWidget::setupBloodPressureTable(const QList<PatientData> &patientList)
{
    QMap<QString, int> bpCounts;
    bpCounts["正常"] = 0; bpCounts["偏高"] = 0; bpCounts["高血压一期"] = 0;
    bpCounts["高血压二期"] = 0; bpCounts["高血压危象"] = 0;
    for (const auto& patient : patientList) {
        int h = patient.high_blood; int l = patient.low_blood;
        if (h > 180 || l > 120) { bpCounts["高血压危象"]++; }
        else if (h >= 140 || l >= 90) { bpCounts["高血压二期"]++; }
        else if (h >= 130 || l >= 80) { bpCounts["高血压一期"]++; }
        else if (h >= 120 && l < 80) { bpCounts["偏高"]++; }
        else if (h < 120 && l < 80) { bpCounts["正常"]++; }
    }
    ui->bloodPressureTable->setRowCount(bpCounts.size());
    int row = 0;
    QStringList levels = {"正常", "偏高", "高血压一期", "高血压二期", "高血压危象"};
    for (const QString &level : levels) {
        QTableWidgetItem *itemLevel = new QTableWidgetItem(level);
        QTableWidgetItem *itemCount = new QTableWidgetItem(QString::number(bpCounts[level]));
        itemCount->setTextAlignment(Qt::AlignCenter);
        ui->bloodPressureTable->setItem(row, 0, itemLevel);
        ui->bloodPressureTable->setItem(row, 1, itemCount);
        row++;
    }
}

void ChartsWidget::on_backButton_clicked()
{
    emit backToMenuRequested();
}
