#ifndef PATIENTDETAILDIALOG_H
#define PATIENTDETAILDIALOG_H

#include <QDialog>

namespace Ui {
class PatientDetailDialog;
}

class PatientDetailDialog : public QDialog
{
    Q_OBJECT
protected:
    // QWidget的showEvent是一个虚函数，我们在这里重写(override)它
    void showEvent(QShowEvent *event) override;
public:
    explicit PatientDetailDialog(const QString& patientId, const QString& patientName, const QString& doctorId, QWidget *parent = nullptr);
    ~PatientDetailDialog();

private slots:
    void on_diagnosisButton_clicked();
    void on_closeButton_clicked();

private:
    void loadPatientInfo();
    void loadCaseHistory();
    void checkScheduleConflict();

    Ui::PatientDetailDialog *ui;
    QString m_patientId;
    QString m_patientName;
    QString m_doctorId;
};

#endif // PATIENTDETAILDIALOG_H
