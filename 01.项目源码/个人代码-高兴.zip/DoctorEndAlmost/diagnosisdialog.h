#ifndef DIAGNOSISDIALOG_H
#define DIAGNOSISDIALOG_H

#include <QDialog>

namespace Ui {
class DiagnosisDialog;
}

class DiagnosisDialog : public QDialog
{
    Q_OBJECT

public:
    // 构造函数现在接收 order_id，而不是 patientId 和 doctorId
    explicit DiagnosisDialog(int orderId, QWidget *parent = nullptr);
    ~DiagnosisDialog();

private slots:
    // 当点击 "OK" 按钮时触发
    void on_buttonBox_accepted();

private:
    Ui::DiagnosisDialog *ui;
    int m_orderId; // 用于存储当前正在操作的病历ID
};

#endif // DIAGNOSISDIALOG_H
