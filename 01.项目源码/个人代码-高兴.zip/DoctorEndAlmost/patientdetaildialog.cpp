#include "patientdetaildialog.h"
#include "ui_patientdetaildialog.h"
#include "diagnosisdialog.h"
#include "mainwindow.h" // <-- 1. 包含 MainWindow 头文件
#include <QMessageBox>
#include <QDate>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>      // <-- 2. 包含 QDebug 头文件
#include <QShowEvent>

PatientDetailDialog::PatientDetailDialog(const QString& patientId, const QString& patientName, const QString& doctorId, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PatientDetailDialog)
{
    ui->setupUi(this);

    m_patientId = patientId.trimmed();
    m_patientName = patientName.trimmed();
    m_doctorId = doctorId.trimmed();

    setWindowTitle("患者详情 - " + m_patientName);

    // ======================= 【调试代码】 =======================
    // 打印传入对话框的ID，确认它们是否正确
    qDebug() << "============================================";
    qDebug() << "PatientDetailDialog CONSTRUCTOR CALLED";
    qDebug() << "Received patientId: " << m_patientId;
    qDebug() << "Received patientName: " << m_patientName;
    qDebug() << "Received doctorId: " << m_doctorId;
    qDebug() << "============================================";
    // ==========================================================
}

PatientDetailDialog::~PatientDetailDialog()
{
    delete ui;
}

void PatientDetailDialog::showEvent(QShowEvent *event)
{
    qDebug() << "PatientDetailDialog::showEvent triggered. Refreshing data...";
    loadPatientInfo();
    loadCaseHistory();
    checkScheduleConflict();
    QDialog::showEvent(event);
}

void PatientDetailDialog::on_diagnosisButton_clicked()
{
    int latestOrderId = -1;
    QSqlQuery query;

    // ======================= 【调试代码】 =======================
    // 在执行查询前，打印将要使用的ID，这是最关键的一步
    qDebug() << "\n'diagnosisButton' CLICKED. Preparing to query medical_order...";
    qDebug() << "Using patientId for query: " << m_patientId << " (as int: " << m_patientId.toInt() << ")";
    qDebug() << "Using doctorId for query: " << m_doctorId << " (as int: " << m_doctorId.toInt() << ")";
    // ==========================================================

    query.prepare("SELECT order_id FROM medical_order "
                  "WHERE student_id = :pid AND doctor_id = :did "
                  "AND (diagnosis_result IS NULL OR diagnosis_result = '') "
                  "ORDER BY issue_time DESC, order_id DESC LIMIT 1");

    query.bindValue(":pid", m_patientId.toInt());
    query.bindValue(":did", m_doctorId.toInt());

    if (query.exec()) {
        if (query.next()) {
            latestOrderId = query.value(0).toInt();
            qDebug() << "SUCCESS: Found a pending medical order. order_id =" << latestOrderId;
        } else {
            qDebug() << "QUERY OK, BUT NO RESULTS: No pending medical order found for this pair.";
        }
    } else {
        qDebug() << "QUERY FAILED: SQL Error -" << query.lastError().text();
    }


    if (latestOrderId == -1) {
        QMessageBox::information(this, "无待处理病历", "未找到该患者提交的、需要您处理的病历。\n\n可能原因：\n1. 患者尚未提交本次问诊的主诉。\n2. 所有历史病历均已处理完毕。");
        return;
    }

    DiagnosisDialog dialog(latestOrderId, this);
    dialog.exec();

    loadCaseHistory();
}

// ... loadCaseHistory, loadPatientInfo 等其他函数保持不变 ...
void PatientDetailDialog::loadCaseHistory()
{
    ui->textBrowserHistory->clear();
    QSqlQuery query;
    query.prepare("SELECT chief_complaint, diagnosis_result, prescription_advice, issue_time "
                  "FROM medical_order "
                  "WHERE student_id = :pid AND doctor_id = :did "
                  "ORDER BY issue_time DESC, order_id DESC");
    query.bindValue(":pid", m_patientId.toInt());
    query.bindValue(":did", m_doctorId.toInt());

    if (query.exec()) {
        bool hasHistory = false;
        while (query.next()) {
            hasHistory = true;
            QString date = query.value("issue_time").toDateTime().toString("yyyy-MM-dd");
            QString complaint = query.value("chief_complaint").toString();
            QString result = query.value("diagnosis_result").toString();
            if (result.isEmpty()) {
                result = "<i style='color: #999;'>待医生填写...</i>";
            }
            QString advice = query.value("prescription_advice").toString();
            if (advice.isEmpty()) {
                advice = "<i style='color: #999;'>待医生填写...</i>";
            }
            ui->textBrowserHistory->append(QString("<h3>%1</h3><p><b>主诉:</b> %2</p><p><b>诊断:</b> %3</p><p><b>医嘱:</b> %4</p><hr>").arg(date, complaint, result, advice));
        }
        if (!hasHistory) {
            ui->textBrowserHistory->setHtml("<p>您与该患者之间暂无历史病历信息。</p>");
        }
    } else {
        ui->textBrowserHistory->setHtml("<p>无法加载历史病例: " + query.lastError().text() + "</p>");
    }
}

void PatientDetailDialog::loadPatientInfo()
{
    QSqlQuery query;
    query.prepare("SELECT name, phone, id_card FROM student_info WHERE student_id = :pid");
    query.bindValue(":pid", m_patientId.toInt());

    if(query.exec() && query.next()) {
        ui->labelPatientName->setText(query.value("name").toString());
        ui->labelPatientId->setText(m_patientId);
        ui->labelPhone->setText(query.value("phone").toString());
        ui->labelIdCard->setText(query.value("id_card").toString());
    } else {
        ui->labelPatientName->setText(m_patientName);
        ui->labelPatientId->setText(m_patientId);
        ui->labelPhone->setText("未知");
        ui->labelIdCard->setText("未知");
    }
}


void PatientDetailDialog::on_closeButton_clicked()
{
    this->close();
}

void PatientDetailDialog::checkScheduleConflict()
{
    QDate examWeekStart(2024, 6, 24);
    QDate examWeekEnd(2024, 7, 5);
    QDate appointmentDate = QDate::currentDate();
    if (appointmentDate >= examWeekStart && appointmentDate <= examWeekEnd) {
        QString reminderText = "💡 <b>提示:</b> 当前为考试周，请留意学生学业安排。";
        ui->reminderLabel->setText(reminderText);
        ui->reminderLabel->setStyleSheet("QLabel { background-color: #FFFBE6; color: #8A6DB; border: 1px solid #FEEFB3; border-radius: 4px; padding: 8px; }");
        ui->reminderLabel->setVisible(true);
    } else {
        ui->reminderLabel->setVisible(false);
    }
}

// ... 其他函数不变 ...

// ... 其他函数不变 ...
