#ifndef GLOBAL_H
#define GLOBAL_H

#include <QString>

extern QString g_loggedInDoctorId;

#endif // GLOBAL_H
