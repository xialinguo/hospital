#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "personalinfodialog.h"
#include "appointmentswidget.h"
#include "chartswidget.h"
#include "remotedatamonitor.h"
#include "chatwidget.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(const QString &doctorId, QWidget *parent = nullptr);
    ~MainWindow();

    QString getCurrentDoctorId() const;

private slots:
    void on_menuBtnAppointments_clicked();
    void on_menuBtnPersonalInfo_clicked();
    void on_menuBtnCharts_clicked();
    void on_menuBtnRemoteData_clicked();
    void on_menuBtnChat_clicked();
    void on_menuBtnReturnToLogin_clicked();

    void showMainMenu();

private:
    Ui::MainWindow *ui;

    AppointmentsWidget* m_appointmentsWidget;
    ChartsWidget* m_chartsWidget;
    RemoteDataMonitor* m_remoteDataMonitor;
    PersonalInfoDialog* m_personalInfoDialog;
    ChatWidget* m_chatWidget;

    QString m_currentDoctorId;

    void switchContent(QWidget* widget);
};

#endif // MAINWINDOW_H
