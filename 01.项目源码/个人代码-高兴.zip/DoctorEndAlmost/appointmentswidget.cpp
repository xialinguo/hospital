#include "appointmentswidget.h"
#include "ui_appointmentswidget.h"
#include "patientdetaildialog.h"
#include "mainwindow.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDateTime>

AppointmentsWidget::AppointmentsWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AppointmentsWidget)
{
    ui->setupUi(this);
    setWindowTitle("预约患者列表");
    this->setStyleSheet("background-color: palette(window);");
    ui->detailButton->setEnabled(false);
}

AppointmentsWidget::~AppointmentsWidget()
{
    delete ui;
}

// ... (文件顶部 #include 和构造/析构函数不变) ...

void AppointmentsWidget::loadAppointmentsForDoctor(const QString &doctorId)
{
    setupTable(doctorId);
}

void AppointmentsWidget::setupTable(const QString &doctorId)
{
    ui->tableWidget->setColumnCount(3);
    ui->tableWidget->setHorizontalHeaderLabels(QStringList() << "患者姓名" << "预约时间" << "学号");
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);
    ui->tableWidget->horizontalHeader()->setStretchLastSection(true);

    ui->tableWidget->setRowCount(0);

    QSqlQuery query;
    // 查询语句本身没有问题，INNER JOIN 也可以工作
    QString sql = "SELECT s.name, a.appointment_time, a.student_id "
                  "FROM appointment AS a "
                  "JOIN student_info AS s ON a.student_id = s.student_id "
                  "WHERE a.doctor_id = :doctorId "
                  "ORDER BY a.appointment_time ASC";

    query.prepare(sql);

    // ======================= 【最终核心修复】 =======================
    // 将 QString 类型的 doctorId 转换为 int 类型再进行绑定，
    // 以确保与数据库中 INT 类型的 doctor_id 字段精确匹配。
    query.bindValue(":doctorId", doctorId.toInt());
    // =============================================================

    if (!query.exec()) {
        QMessageBox::critical(this, "数据库错误", query.lastError().text());
        return;
    }

    while (query.next()) {
        QString name = query.value("name").toString();
        QString time = query.value("appointment_time").toDateTime().toString("yyyy-MM-dd hh:mm");
        QString id = query.value("student_id").toString();

        int row = ui->tableWidget->rowCount();
        ui->tableWidget->insertRow(row);
        ui->tableWidget->setItem(row, 0, new QTableWidgetItem(name));
        ui->tableWidget->setItem(row, 1, new QTableWidgetItem(time));
        ui->tableWidget->setItem(row, 2, new QTableWidgetItem(id));
    }

    if (ui->tableWidget->rowCount() > 0) {
        ui->tableWidget->selectRow(0);
        ui->detailButton->setEnabled(true);
    } else {
        ui->detailButton->setEnabled(false);
    }
}

// ... (文件其余部分不变) ...

void AppointmentsWidget::on_tableWidget_currentItemChanged(QTableWidgetItem *current, QTableWidgetItem *previous)
{
    Q_UNUSED(previous);
    ui->detailButton->setEnabled(current != nullptr);
}

void AppointmentsWidget::on_tableWidget_cellDoubleClicked(int row, int column)
{
    Q_UNUSED(column);
    showPatientDetail(row);
}

void AppointmentsWidget::on_detailButton_clicked()
{
    int currentRow = ui->tableWidget->currentRow();
    if (currentRow >= 0) {
        showPatientDetail(currentRow);
    }
}

void AppointmentsWidget::showPatientDetail(int row)
{
    if (row < 0) return;
    QString patientId = ui->tableWidget->item(row, 2)->text();
    QString patientName = ui->tableWidget->item(row, 0)->text();

    // 【修改】直接从 MainWindow 的实例获取 doctorId，而不是通过复杂的父对象转换
    MainWindow* mainWindow = nullptr;
    // 遍历所有顶层窗口找到 MainWindow
    foreach (QWidget *widget, QApplication::topLevelWidgets()) {
        if (MainWindow* mw = qobject_cast<MainWindow*>(widget)) {
            mainWindow = mw;
            break;
        }
    }

    QString doctorId = "";
    if (mainWindow) {
        doctorId = mainWindow->getCurrentDoctorId();
    } else {
        qDebug() << "FATAL: Could not find MainWindow instance to get current doctor ID!";
        // 这里可以加一个错误提示
        QMessageBox::critical(this, "严重错误", "无法获取当前登录的医生信息！");
        return;
    }

    PatientDetailDialog dialog(patientId, patientName, doctorId, this);
    dialog.exec();
}

void AppointmentsWidget::on_backButton_clicked()
{
    emit backToMenuRequested();
}
