#include "server.h"

Server::Server(QObject *parent) : QTcpServer(parent)
{
    if (!this->listen(QHostAddress::Any, 8765)) {
        qDebug() << "服务器启动失败:" << this->errorString();
        exit(1);
    } else {
        qDebug() << "服务器启动成功，监听端口 8765";
        qDebug() << "服务器监听地址:" << this->serverAddress().toString()
                 << "端口:" << this->serverPort();
    }
}

void Server::incomingConnection(qintptr socketDescriptor)
{
    QTcpSocket *socket = new QTcpSocket(this);
    socket->setSocketDescriptor(socketDescriptor);

    qDebug() << "客户端已连接：" << socket->peerAddress().toString()
             << ":" << socket->peerPort();

    // 读取数据
    connect(socket, &QTcpSocket::readyRead, [this, socket]() {
        QByteArray data = socket->readAll();
        handleMessage(socket, data);
    });

    // 客户端断开
    connect(socket, &QTcpSocket::disconnected, [this, socket]() {
        QString id = m_socketIdMap.value(socket);
        if (!id.isEmpty()) {
            m_clientMap.remove(id);
            m_socketIdMap.remove(socket);
            qDebug() << "客户端断开，工号:" << id;
        }
        socket->deleteLater();
    });
}

// 处理消息：第一次消息是工号注册，其余消息格式：senderId|targetId|content
void Server::handleMessage(QTcpSocket* socket, const QByteArray &data)
{
    QString msg = QString::fromUtf8(data).trimmed();

    // 如果 socket 没有注册工号，则第一条消息是注册
    if (!m_socketIdMap.contains(socket)) {
        QString clientId = msg;
        if (!clientId.isEmpty()) {
            m_clientMap[clientId] = socket;
            m_socketIdMap[socket] = clientId;
            qDebug() << "注册客户端工号:" << clientId;
            socket->write("注册成功\n");
        }
        return;
    }

    // 消息格式：senderId|targetId|content
    QStringList parts = msg.split("|");
    if (parts.size() < 3) {
        qDebug() << "消息格式错误:" << msg;
        return;
    }

    QString senderId = parts[0];
    QString targetId = parts[1];
    QString content = parts[2];

    qDebug() << "收到消息 from" << senderId << "to" << targetId << ":" << content;

    // 转发给目标客户端
    if (m_clientMap.contains(targetId)) {
        QTcpSocket* targetSocket = m_clientMap[targetId];
        targetSocket->write(msg.toUtf8());
    } else {
        qDebug() << "目标工号不在线:" << targetId;
    }
}
