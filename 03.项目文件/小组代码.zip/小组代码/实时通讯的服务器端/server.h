#ifndef SERVER_H
#define SERVER_H

#include <QTcpServer>
#include <QTcpSocket>
#include <QMap>
#include <QDebug>

class Server : public QTcpServer
{
    Q_OBJECT
public:
    explicit Server(QObject *parent = nullptr);

protected:
    void incomingConnection(qintptr socketDescriptor) override;

private:
    // 保存工号与客户端 socket 的映射
    QMap<QString, QTcpSocket*> m_clientMap;

    // 绑定 socket 与工号
    QMap<QTcpSocket*, QString> m_socketIdMap;

    // 处理消息函数
    void handleMessage(QTcpSocket* socket, const QByteArray &data);
};

#endif // SERVER_H
