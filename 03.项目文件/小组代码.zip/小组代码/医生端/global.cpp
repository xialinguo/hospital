#include "global.h"

QString g_loggedInDoctorId = "";  // 默认空
