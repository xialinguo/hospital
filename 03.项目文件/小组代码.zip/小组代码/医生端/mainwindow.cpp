#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "logindialog.h"
#include <QMessageBox>
#include <QHBoxLayout>
#include <QApplication>
#include <QPixmap>
#include <QTime>

MainWindow::MainWindow(const QString &doctorId, QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_appointmentsWidget(nullptr)
    , m_chartsWidget(nullptr)
    , m_remoteDataMonitor(nullptr)
    , m_personalInfoDialog(nullptr)
    , m_chatWidget(nullptr)
    , m_currentDoctorId(doctorId)
{
    ui->setupUi(this);
    setWindowTitle("北京理工大学智慧校医院 - 医生端");

    // --- 这部分代码不变 ---
    QStringList statusTips;
    statusTips << "呵护师生身心健康，共筑校园安全防线。"
               << "医者仁心，感谢您的辛勤付出。"
               << "每一次诊断，都是一份沉甸甸的责任。"
               << "温馨提示：工作再忙，也别忘了喝水哦。"
               << "守护校园健康，我们与你同行。";
    QTime time = QTime::currentTime();
    qsrand((uint)time.msec());
    QString selectedTip = statusTips.at(qrand() % statusTips.size());
    statusBar()->showMessage(selectedTip);
    QString mainStyleSheet = R"(
        QWidget#centralwidget { background-color: #F2F2F2; }
        QStackedWidget, QWidget#mainMenuPage, QWidget#contentPage { background: transparent; }
        QLabel#titleLabel { font-size: 36px; font-weight: bold; color: rgb(0, 108, 57); qproperty-alignment: 'AlignCenter'; }
        QWidget#buttonContainer { background: transparent; }
        QWidget#buttonContainer QPushButton { background-color: white; color: rgb(0, 108, 57); border: 2px solid rgb(0, 108, 57); border-radius: 10px; font-size: 16px; font-weight: bold; min-height: 50px; min-width: 180px; }
        QWidget#buttonContainer QPushButton:hover { background-color: rgb(0, 108, 57); color: white; }
        QWidget#buttonContainer QPushButton:pressed { background-color: rgb(0, 80, 42); border-color: rgb(0, 80, 42); }
    )";
    ui->centralwidget->setStyleSheet(mainStyleSheet);
    QPixmap logo(":/images/bit_logo.png");
    if (!logo.isNull()) {
        ui->logoLabel->setPixmap(logo.scaled(ui->logoLabel->size(),
                                            Qt::KeepAspectRatio,
                                            Qt::SmoothTransformation));
    }
    // --- 代码不变部分结束 ---

    m_appointmentsWidget = new AppointmentsWidget(); // 不再设置父对象
    m_chartsWidget = new ChartsWidget();
    m_remoteDataMonitor = new RemoteDataMonitor();
    m_chatWidget = new ChatWidget();

    // 【关键修复】删除所有对 contentPage 布局的操作
    // QHBoxLayout* layout = new QHBoxLayout(ui->contentPage);
    // layout->setContentsMargins(0, 0, 0, 0);
    // ui->contentPage->setLayout(layout);

    // 【关键修复】确保 contentPage 有一个布局，以便接收子控件
    if (!ui->contentPage->layout()) {
        new QVBoxLayout(ui->contentPage); // 给它一个简单的垂直布局
    }
    ui->contentPage->layout()->setContentsMargins(0, 0, 0, 0);


    connect(m_appointmentsWidget, &AppointmentsWidget::backToMenuRequested, this, &MainWindow::showMainMenu);
    connect(m_chartsWidget, &ChartsWidget::backToMenuRequested, this, &MainWindow::showMainMenu);
    connect(m_remoteDataMonitor, &RemoteDataMonitor::backToMenuRequested, this, &MainWindow::showMainMenu);
    connect(m_chatWidget, &ChatWidget::backToMenuRequested, this, &MainWindow::showMainMenu);

    ui->stackedWidget->setCurrentWidget(ui->mainMenuPage);
}

MainWindow::~MainWindow()
{
    delete ui;
}

QString MainWindow::getCurrentDoctorId() const
{
    return m_currentDoctorId;
}

void MainWindow::switchContent(QWidget* widget)
{
    QLayoutItem* item;
    // 清理 contentPage 中已有的控件
    while ((item = ui->contentPage->layout()->takeAt(0)) != nullptr) {
        if (item->widget()) {
            item->widget()->setParent(nullptr);
        }
        delete item;
    }
    // 将新控件添加到 contentPage 的布局中
    ui->contentPage->layout()->addWidget(widget);
    ui->stackedWidget->setCurrentWidget(ui->contentPage);
}

// ... (所有 on_menuBtn..._clicked 槽函数和 showMainMenu 都不需要修改) ...
void MainWindow::on_menuBtnAppointments_clicked()
{
    m_appointmentsWidget->loadAppointmentsForDoctor(m_currentDoctorId);
    switchContent(m_appointmentsWidget);
}

void MainWindow::on_menuBtnPersonalInfo_clicked()
{
    if (!m_personalInfoDialog) {
        m_personalInfoDialog = new PersonalInfoDialog(m_currentDoctorId, this);
    }
    if (m_personalInfoDialog->isHidden()) {
        m_personalInfoDialog->show();
    } else {
        m_personalInfoDialog->raise();
        m_personalInfoDialog->activateWindow();
    }
}

void MainWindow::on_menuBtnCharts_clicked()
{
    switchContent(m_chartsWidget);
}

void MainWindow::on_menuBtnRemoteData_clicked()
{
    m_remoteDataMonitor->loadDataForDoctor(m_currentDoctorId);
    switchContent(m_remoteDataMonitor);
}

void MainWindow::on_menuBtnChat_clicked()
{
    m_chatWidget->loadPatientList(m_currentDoctorId);
    switchContent(m_chatWidget);
}

void MainWindow::on_menuBtnReturnToLogin_clicked()
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "确认", "确定要返回登录界面吗？", QMessageBox::Yes|QMessageBox::No);
    if (reply == QMessageBox::Yes) {
        this->hide();
        LoginDialog loginDialog;
        if (loginDialog.exec() == QDialog::Accepted) {
            m_currentDoctorId = loginDialog.loggedInDoctorId();
            if(m_personalInfoDialog) {
                delete m_personalInfoDialog;
                m_personalInfoDialog = nullptr;
            }
            if(m_chatWidget) {
                delete m_chatWidget;
                m_chatWidget = new ChatWidget();
                connect(m_chatWidget, &ChatWidget::backToMenuRequested, this, &MainWindow::showMainMenu);
            }
            showMainMenu();
            this->show();
        } else {
            QApplication::quit();
        }
    }
}

void MainWindow::showMainMenu()
{
    ui->stackedWidget->setCurrentWidget(ui->mainMenuPage);
}
