#include "registerdialog.h"
#include "ui_registerdialog.h"
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>

RegisterDialog::RegisterDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RegisterDialog)
{
    ui->setupUi(this);
    setWindowTitle("医生注册");

    ui->bannerFrame->setStyleSheet(
        "QFrame#bannerFrame {"
        "  border-image: url(:/images/doctor_avatar.png) 0 0 0 0 stretch stretch;"
        "  border: none;"
        "}"
    );
}

RegisterDialog::~RegisterDialog()
{
    delete ui;
}

void RegisterDialog::on_buttonBox_accepted()
{
    // 从UI获取所有输入信息
    QString id = ui->idLineEdit->text();
    QString name = ui->nameLineEdit->text();
    QString gender = ui->genderComboBox->currentText();
    QString department = ui->departmentLineEdit->text();
    QString position = ui->positionLineEdit->text();
    QString phone = ui->phoneLineEdit->text();
    QString password = ui->passwordLineEdit->text();
    QString confirmPassword = ui->confirmPasswordLineEdit->text();

    // 验证所有字段是否已填写
    if (id.isEmpty() || name.isEmpty() || department.isEmpty() ||
        position.isEmpty() || phone.isEmpty() || password.isEmpty() ||
        confirmPassword.isEmpty()) {
        QMessageBox::warning(this, "注册失败", "所有项目均为必填项！");
        return;
    }

    // 验证两次输入的密码是否一致
    if (password != confirmPassword) {
        QMessageBox::warning(this, "注册失败", "两次输入的密码不一致！");
        return;
    }

    // 准备数据库查询
    QSqlQuery query;
    query.prepare("INSERT INTO doctor_info (doctor_id, name, gender, department, title, phone, password) "
                  "VALUES (:id, :name, :gender, :department, :title, :phone, :password)");

    // 绑定所有值
    query.bindValue(":id", id);
    query.bindValue(":name", name);
    query.bindValue(":gender", gender);
    query.bindValue(":department", department);
    query.bindValue(":title", position); // UI中的 "position" 对应数据库的 "title"
    query.bindValue(":phone", phone);
    query.bindValue(":password", password);

    // 执行查询并处理结果
    if (!query.exec()) {
        if (query.lastError().number() == 1062) { // 检查是否是主键或唯一键冲突
             QMessageBox::critical(this, "注册失败", "工号、姓名或电话号码已被注册，请检查后重试。");
        } else {
             QMessageBox::critical(this, "注册失败", "数据库错误: " + query.lastError().text());
        }
        return;
    }

    QMessageBox::information(this, "注册成功", "您的账号已成功创建！请使用工号和密码登录。");
    accept(); // 成功后关闭对话框
}
