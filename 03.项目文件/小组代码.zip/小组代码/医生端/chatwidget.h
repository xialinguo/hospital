#ifndef CHATWIDGET_H
#define CHATWIDGET_H

#include <QWidget>
#include <QMap>
#include <QTcpSocket>
#include <QAbstractSocket>

namespace Ui {
class ChatWidget;
}

class ChatWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ChatWidget(QWidget *parent = nullptr);
    ~ChatWidget();

    void loadPatientList(const QString &doctorId);

signals:
    void backToMenuRequested();

protected:
    void showEvent(QShowEvent *event) override;

private slots:
    void on_sendButton_clicked();
    void on_backButton_clicked();
    void on_patientComboBox_currentIndexChanged(int index);

    void onConnected();
    void onDisconnected();
    void onReadyRead();
    void displayError(QAbstractSocket::SocketError socketError);

private:
    Ui::ChatWidget *ui;
    QMap<QString, QString> m_patientMap;
    QString m_currentDoctorId;
    QString m_currentPatientId;

    QTcpSocket *m_socket;
    bool m_isFirstShow = true;

    void updateUIState();
    void connectToServer();
    void registerDoctorId();
};

#endif // CHATWIDGET_H
