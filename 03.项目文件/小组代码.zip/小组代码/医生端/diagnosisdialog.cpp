#include "diagnosisdialog.h"
#include "ui_diagnosisdialog.h"
#include <QMessageBox>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>

// 构造函数：通过 order_id 加载现有数据
DiagnosisDialog::DiagnosisDialog(int orderId, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DiagnosisDialog),
    m_orderId(orderId)
{
    ui->setupUi(this);
    setWindowTitle("填写诊断与医嘱");

    // 主诉框始终是只读的
    ui->mainComplaintEdit->setReadOnly(true);
    ui->mainComplaintEdit->setStyleSheet("background-color: #f5f5f5;");

    // 断开默认的 accept 连接，以便我们自定义保存逻辑
    disconnect(ui->buttonBox, &QDialogButtonBox::accepted, this, &QDialog::accept);

    qDebug() << "诊断对话框正在加载 order_id:" << m_orderId;

    // 根据传入的 order_id 精确查找病历记录
    QSqlQuery query;
    query.prepare("SELECT chief_complaint, diagnosis_result, prescription_advice "
                  "FROM medical_order WHERE order_id = :oid");
    query.bindValue(":oid", m_orderId);

    if (query.exec() && query.next()) {
        QString complaint = query.value("chief_complaint").toString();
        qDebug() << "从数据库加载的主诉内容:" << complaint;
        ui->mainComplaintEdit->setPlainText(complaint);
        ui->diagnosisResultEdit->setPlainText(query.value("diagnosis_result").toString());
        ui->prescriptionEdit->setPlainText(query.value("prescription_advice").toString());
    } else {
        qDebug() << "[错误] 无法根据 order_id 加载病历信息:" << query.lastError().text();
        QMessageBox::critical(this, "加载失败", "无法加载指定的病历信息。");
    }
}

DiagnosisDialog::~DiagnosisDialog()
{
    delete ui;
}

// 保存逻辑：从 INSERT 改为 UPDATE
void DiagnosisDialog::on_buttonBox_accepted()
{
    QString diagnosisResult = ui->diagnosisResultEdit->toPlainText().trimmed();
    QString prescription = ui->prescriptionEdit->toPlainText().trimmed();

    if (prescription.isEmpty() || diagnosisResult.isEmpty()) {
        QMessageBox::warning(this, "信息不完整", "处方和诊断结果为必填项！");
        return;
    }

    // 使用 UPDATE 语句在现有记录上更新信息
    QSqlQuery query;
    query.prepare("UPDATE medical_order SET "
                  "diagnosis_result = :diag, "
                  "prescription_advice = :adv, "
                  "issue_time = NOW() " // 同时更新记录时间为当前时间
                  "WHERE order_id = :oid");
    query.bindValue(":diag", diagnosisResult);
    query.bindValue(":adv", prescription);
    query.bindValue(":oid", m_orderId);

    if (!query.exec()) {
        QMessageBox::critical(this, "数据库错误", "保存医嘱失败: " + query.lastError().text());
        return;
    }

    // 如果执行成功，才手动调用 accept() 来关闭对话框
    QDialog::accept();
}
