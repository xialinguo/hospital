#include "chatwidget.h"
#include "ui_chatwidget.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QHostAddress>
#include <QDebug>

ChatWidget::ChatWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ChatWidget)
{
    ui->setupUi(this);
    setWindowTitle("医患沟通");
    this->setStyleSheet("background-color: palette(window);");

    m_socket = new QTcpSocket(this);
    connect(m_socket, &QTcpSocket::connected, this, &ChatWidget::onConnected);
    connect(m_socket, &QTcpSocket::disconnected, this, &ChatWidget::onDisconnected);
    connect(m_socket, &QTcpSocket::readyRead, this, &ChatWidget::onReadyRead);
    connect(m_socket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(displayError(QAbstractSocket::SocketError)));

    updateUIState();
}

ChatWidget::~ChatWidget()
{
    delete ui;
}

void ChatWidget::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);
    if (m_isFirstShow) {
        m_isFirstShow = false;
        connectToServer();
    }
}

void ChatWidget::connectToServer()
{
    if (m_socket->state() == QAbstractSocket::UnconnectedState) {
        const QString serverIp = "60.205.162.162";
        const quint16 serverPort = 8765;
        ui->chatHistoryBrowser->append(QString("<i>正在连接到聊天服务器 %1:%2...</i>").arg(serverIp).arg(serverPort));
        m_socket->connectToHost(QHostAddress(serverIp), serverPort);
    }
}

// 【关键改动】只注册医生ID，不带消息内容
void ChatWidget::registerDoctorId()
{
    QString doctorIdOnly = m_currentDoctorId.section('|', 0, 0); // 取第一个字段
    m_socket->write(doctorIdOnly.toUtf8());
    m_socket->flush();
    qDebug() << "注册医生ID:" << doctorIdOnly;
}

void ChatWidget::loadPatientList(const QString &doctorId)
{
    m_currentDoctorId = doctorId;

    ui->patientComboBox->clear();
    m_patientMap.clear();
    ui->patientComboBox->addItem("请选择一位患者进行沟通");

    QSqlQuery query;
    query.prepare("SELECT DISTINCT s.student_id, s.name "
                  "FROM student_info s "
                  "JOIN appointment a ON s.student_id = a.student_id "
                  "WHERE a.doctor_id = :doctorId "
                  "ORDER BY s.name ASC");
    query.bindValue(":doctorId", doctorId);

    if (!query.exec()) {
        QMessageBox::critical(this, "数据库错误", "无法加载患者列表: " + query.lastError().text());
        return;
    }

    while (query.next()) {
        QString patientId = query.value("student_id").toString();
        QString patientName = query.value("name").toString();
        ui->patientComboBox->addItem(patientName);
        m_patientMap.insert(patientName, patientId);
    }
}

void ChatWidget::on_patientComboBox_currentIndexChanged(int index)
{
    if (index <= 0) {
        m_currentPatientId.clear();
        ui->chatHistoryBrowser->clear();
        ui->chatHistoryBrowser->setPlaceholderText("请选择一位患者进行沟通");
    } else {
        QString currentName = ui->patientComboBox->currentText();
        m_currentPatientId = m_patientMap.value(currentName);
        ui->chatHistoryBrowser->clear();
        ui->chatHistoryBrowser->append(QString("<b>--- 开始与 %1 的对话 ---</b>").arg(currentName));
    }
    updateUIState();
}

void ChatWidget::on_sendButton_clicked()
{
    QString message = ui->messageLineEdit->text().trimmed();
    if (message.isEmpty() || m_currentDoctorId.isEmpty() || m_currentPatientId.isEmpty())
        return;

    QString formattedMessage = QString("%1|%2|%3").arg(m_currentDoctorId, m_currentPatientId, message);
    m_socket->write(formattedMessage.toUtf8());
    m_socket->flush();
    ui->chatHistoryBrowser->append(QString("<p style='text-align:right; color:green;'><b>我:</b> %1</p>").arg(message));
    ui->messageLineEdit->clear();
}

void ChatWidget::on_backButton_clicked()
{
    if (m_socket->state() != QAbstractSocket::UnconnectedState)
        m_socket->disconnectFromHost();
    emit backToMenuRequested();
}

void ChatWidget::onConnected()
{
    ui->chatHistoryBrowser->append("<i>✅ 已成功连接到聊天服务器。</i>");
    registerDoctorId(); // 连接成功后注册医生ID
    updateUIState();
}

void ChatWidget::onDisconnected()
{
    ui->chatHistoryBrowser->append("<i>❌ 与聊天服务器的连接已断开。</i>");
    updateUIState();
}

void ChatWidget::onReadyRead()
{
    QByteArray data = m_socket->readAll();
    QString messageFromServer = QString::fromUtf8(data);

    QStringList parts = messageFromServer.split("|");
    if (parts.size() != 3) return;

    QString sender = parts[0];
    QString target = parts[1];
    QString content = parts[2];

    if (target == m_currentDoctorId.section('|', 0, 0)) {
        ui->chatHistoryBrowser->append(QString("<b>%1:</b> %2").arg(sender, content));
    }
}

void ChatWidget::displayError(QAbstractSocket::SocketError socketError)
{
    Q_UNUSED(socketError);
    if (m_socket->state() != QAbstractSocket::UnconnectedState) {
        QMessageBox::warning(this, "网络错误", m_socket->errorString());
    }
    updateUIState();
}

void ChatWidget::updateUIState()
{
    bool canSend = (m_socket->state() == QAbstractSocket::ConnectedState) && !m_currentPatientId.isEmpty();
    ui->messageLineEdit->setEnabled(canSend);
    ui->sendButton->setEnabled(canSend);
}
