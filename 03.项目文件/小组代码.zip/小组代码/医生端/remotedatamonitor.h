#ifndef REMOTEDATAMONITOR_H
#define REMOTEDATAMONITOR_H

#include <QWidget>
#include <QtCharts>
#include <QMap> // 【关键修复】重新包含 QMap

QT_CHARTS_USE_NAMESPACE

namespace Ui {
class RemoteDataMonitor;
}

class RemoteDataMonitor : public QWidget
{
    Q_OBJECT

public:
    explicit RemoteDataMonitor(QWidget *parent = nullptr);
    ~RemoteDataMonitor();

    void loadDataForDoctor(const QString &doctorId);

signals:
    void backToMenuRequested();

private slots:
    void on_backButton_clicked();
    void on_patientComboBox_currentIndexChanged(int index);

private:
    Ui::RemoteDataMonitor *ui;

    // 【关键修复】重新引入 patientMap，与 ChatWidget 保持一致
    QMap<QString, QString> m_patientMap;

    void loadPatientList(const QString &doctorId);
    void updateDashboard(const QString &studentId);
    void clearDashboard();

    QChart* createBmiChart(double bmi);
    void setCardStyle(QFrame *card, const QColor &borderColor);
};

#endif // REMOTEDATAMONITOR_H
