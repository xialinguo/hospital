#ifndef APPOINTMENTSWIDGET_H
#define APPOINTMENTSWIDGET_H

#include <QWidget>
#include <QTableWidgetItem>

// 前向声明 MainWindow
class MainWindow;

namespace Ui {
class AppointmentsWidget;
}

class AppointmentsWidget : public QWidget
{
    Q_OBJECT

public:
    explicit AppointmentsWidget(QWidget *parent = nullptr);
    ~AppointmentsWidget();

    void loadAppointmentsForDoctor(const QString &doctorId);

signals:
    void backToMenuRequested();

private slots:
    void on_tableWidget_cellDoubleClicked(int row, int column);
    void showPatientDetail(int row);
    void on_backButton_clicked();
    void on_detailButton_clicked();
    void on_tableWidget_currentItemChanged(QTableWidgetItem *current, QTableWidgetItem *previous);

private:
    Ui::AppointmentsWidget *ui;
    void setupTable(const QString &doctorId);
};

#endif // APPOINTMENTSWIDGET_H
