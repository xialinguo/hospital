#ifndef DIAGNOSISWIDGET_H
#define DIAGNOSISWIDGET_H

#include <QWidget>
#include <QtSql>

// 假设您在某个全局头文件或cpp中定义了全局变量
// 此处我们用extern来声明它，表示我们将使用在别处定义的这个变量
extern int g_currentStudentId;

namespace Ui {
class DiagnosisWidget;
}

class DiagnosisWidget : public QWidget
{
    Q_OBJECT

public:
    // 构造函数简化，只需要传入doctorId
    explicit DiagnosisWidget(int doctorId, QWidget *parent = nullptr);
    ~DiagnosisWidget();

private slots:
    void on_submitButton_clicked();
    void on_clearButton_clicked();

private:
    void setupDatabaseConnection();
    void createNewOrder(); // 查找或创建医嘱记录，并加载数据

    Ui::DiagnosisWidget *ui;
    int m_doctorId;
    int m_orderId; // 用于存储当前操作的医嘱ID
    QSqlDatabase m_db;
};

#endif // DIAGNOSISWIDGET_H
