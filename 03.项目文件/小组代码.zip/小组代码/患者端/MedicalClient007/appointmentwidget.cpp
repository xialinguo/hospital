#include "appointmentwidget.h"
#include "ui_appointmentwidget.h"
#include <QMessageBox>
#include <QDate>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include "global.h"

AppointmentWidget::AppointmentWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AppointmentWidget)
{
    ui->setupUi(this);

    // 设置日期范围
    ui->DateEdit->setDate(QDate::currentDate());
    ui->DateEdit->setMinimumDate(QDate::currentDate());
    ui->DateEdit->setMaximumDate(QDate::currentDate().addDays(30));

    // 设置 ComboBox 为可编辑
    ui->doctorComboBox->setEditable(true);
    ui->timeComboBox->setEditable(true);

    // 加载医生列表
    loadDoctors();

    // 直接显示所有时间段
    ui->timeComboBox->clear();
    ui->timeComboBox->addItem("请选择时间段");
    QStringList allTimes;
    allTimes << "09:00-10:00" << "10:00-11:00" << "11:00-12:00"
             << "14:00-15:00" << "15:00-16:00" << "16:00-17:00";
    ui->timeComboBox->addItems(allTimes);

    // 日期变化无需额外处理
}

AppointmentWidget::~AppointmentWidget()
{
    delete ui;
}
void AppointmentWidget::on_dateEdit_dateChanged(const QDate &date)
{
    Q_UNUSED(date);
    // 现在不做任何处理，时间段固定显示全部
}

void AppointmentWidget::loadDoctors()
{
    ui->doctorComboBox->clear();
    ui->doctorComboBox->addItem("请选择医生");

    QSqlDatabase db = QSqlDatabase::database();
    if (!db.isOpen()) {
        QMessageBox::critical(this, "数据库错误", "数据库未连接！");
        return;
    }

    QSqlQuery query(db);
    if (!query.exec("SELECT doctor_id, name, department FROM doctor_info")) {
        QMessageBox::critical(this, "错误", "加载医生列表失败: " + query.lastError().text());
        return;
    }

    while (query.next()) {
        int doctorId = query.value(0).toInt();
        QString name = query.value(1).toString();
        QString dept = query.value(2).toString();
        ui->doctorComboBox->addItem(QString("%1 - %2").arg(name).arg(dept), doctorId);
    }
}

void AppointmentWidget::on_bookButton_clicked()
{
    if (ui->doctorComboBox->currentIndex() == 0) {
        QMessageBox::warning(this, "警告", "请选择医生");
        return;
    }
    if (ui->timeComboBox->currentIndex() == 0) {
        QMessageBox::warning(this, "警告", "请选择时间段");
        return;
    }

    int doctorId = ui->doctorComboBox->currentData().toInt();
    QString date = ui->DateEdit->date().toString("yyyy-MM-dd");
    QString timeRange = ui->timeComboBox->currentText();

    // 取时间段的起始时间作为 appointment_time
    QString timeStart = timeRange.split("-").first();
    QString dateTimeStr = date + " " + timeStart + ":00";
    QDateTime appointmentDateTime = QDateTime::fromString(dateTimeStr, "yyyy-MM-dd hh:mm:ss");

    QSqlDatabase db = QSqlDatabase::database();
    if (!db.isOpen()) {
        QMessageBox::critical(this, "数据库错误", "数据库未连接！");
        return;
    }

    QSqlQuery query(db);
    query.prepare("INSERT INTO appointment (department, appointment_time, doctor_id, student_id) "
                  "VALUES (:department, :appointment_time, :doctor_id, :student_id)");
    query.bindValue(":department", ui->doctorComboBox->currentText().split(" - ").last());
    query.bindValue(":appointment_time", appointmentDateTime);
    query.bindValue(":doctor_id", doctorId);
    query.bindValue(":student_id", g_studentId); // 当前登录学生ID

    if (!query.exec()) {
        // 捕获唯一约束重复预约错误
        if (query.lastError().text().contains("Duplicate entry")) {
            QMessageBox::warning(this, "预约失败", "该时间段已被预约，请选择其他时间段");
        } else {
            QMessageBox::critical(this, "预约失败", "数据库错误: " + query.lastError().text());
        }
        return;
    }

    QMessageBox::information(this, "预约成功",
        QString("您已成功预约：\n医生：%1\n日期：%2\n时间：%3")
        .arg(ui->doctorComboBox->currentText())
        .arg(date)
        .arg(timeRange));

    // 重置选择
    ui->doctorComboBox->setCurrentIndex(0);
    ui->timeComboBox->setCurrentIndex(0);
}
