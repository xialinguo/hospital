#include "loginwindow.h"
#include "DatabaseManager.h"
#include <QApplication>
#include <QMessageBox>

// 全局数据库管理对象
DatabaseManager g_dbManager;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // 尝试连接数据库
    QString host = "60.205.162.162";   // 云服务器 IP
    int port = 3306;                    // MySQL 端口
    QString dbName = "smart_medical";   // 数据库名
    QString user = "student";           // 用户名
    QString password = "your_password";// 密码

    if (!g_dbManager.connect(host, dbName, user, password, port))
    {
        QMessageBox::critical(nullptr, "数据库错误",
                              "无法连接数据库，请检查连接参数。");
        return -1; // 数据库连接失败，退出
    }

    // 显示登录窗口
    LoginWindow loginWindow;
    loginWindow.show();

    int ret = a.exec();

    // 程序退出前断开数据库
    g_dbManager.disconnect();

    return ret;
}
