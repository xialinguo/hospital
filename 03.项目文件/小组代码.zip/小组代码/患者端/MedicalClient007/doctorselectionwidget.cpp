#include "doctorselectionwidget.h"
#include "ui_doctorselectionwidget.h"
#include <QMessageBox>
#include <QDebug>
#include <QSqlError>
#include "global.h"
#include <QListWidgetItem>

// 假设全局学生ID在这里或main.cpp中定义
 // 初始值为0，登录后应被赋真实值

DoctorSelectionWidget::DoctorSelectionWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::DoctorSelectionWidget)
{
    ui->setupUi(this);

    setupDatabaseConnection();
    loadDoctors();
}

DoctorSelectionWidget::~DoctorSelectionWidget()
{
    if (m_db.isOpen()) {
        m_db.close();
    }
    delete ui;
}

void DoctorSelectionWidget::setupDatabaseConnection()
{
    if (QSqlDatabase::contains("qt_sql_default_connection")) {
        m_db = QSqlDatabase::database("qt_sql_default_connection");
    } else {
        m_db = QSqlDatabase::addDatabase("QMYSQL");
        m_db.setHostName("127.0.0.1");
        m_db.setPort(3306);
        m_db.setDatabaseName("your_db_name");
        m_db.setUserName("your_username");
        m_db.setPassword("your_password");
    }

    if (!m_db.open()) {
        QMessageBox::critical(this, "数据库错误", "无法连接到数据库: " + m_db.lastError().text());
    }
}

// 从数据库加载医生列表并显示在QListWidget中
void DoctorSelectionWidget::loadDoctors()
{
    if (!m_db.isOpen()) return;

    QSqlQuery query(m_db);
    // 假设您的医生表名为 doctor_info
    if (query.exec("SELECT doctor_id, name, department FROM doctor_info")) {
        while (query.next()) {
            int doctorId = query.value("doctor_id").toInt();
            QString name = query.value("name").toString();
            QString department = query.value("department").toString();

            // 创建一个新的列表项
            QListWidgetItem *item = new QListWidgetItem(QString("%1 (%2)").arg(name, department));

            // **关键步骤**: 将医生的ID作为数据存储在列表项中
            // 这样我们之后可以获取到它，而不仅仅是看到名字
            item->setData(Qt::UserRole, doctorId);

            ui->doctorListWidget->addItem(item);
        }
    } else {
        QMessageBox::critical(this, "查询失败", "无法加载医生列表: " + query.lastError().text());
    }
}


// ... (其他函数保持不变) ...
// 当用户点击“进入诊室”按钮时
void DoctorSelectionWidget::on_selectButton_clicked()
{
    QListWidgetItem *currentItem = ui->doctorListWidget->currentItem();

    // 检查用户是否真的选择了一项
    if (!currentItem) {
        QMessageBox::warning(this, "提示", "请先从列表中选择一位医生！");
        return;
    }

    // 从选择的项中取出我们之前存储的医生ID
    int selectedDoctorId = currentItem->data(Qt::UserRole).toInt();
    emit doctorSelected(selectedDoctorId);

}
