#include "healthassessmentwidget.h"
#include "ui_healthassessmentwidget.h"
#include <QMessageBox>
#include <QDateTime>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include "global.h"  // 这里假设 g_studentId 已定义并存储当前登录学生ID

HealthAssessmentWidget::HealthAssessmentWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::HealthAssessmentWidget)
{
    ui->setupUi(this);

    // 设置范围
    ui->heightSpinBox->setRange(100, 220);
    ui->weightSpinBox->setRange(30, 150);
    ui->bpHighSpinBox->setRange(60, 200);
    ui->bpLowSpinBox->setRange(40, 120);
    ui->heartRateSpinBox->setRange(40, 120);

    // 设置默认值
    ui->heightSpinBox->setValue(170);
    ui->weightSpinBox->setValue(65);
    ui->bpHighSpinBox->setValue(120);
    ui->bpLowSpinBox->setValue(80);
    ui->heartRateSpinBox->setValue(75);

    // 按钮绑定
    connect(ui->assessButton, &QPushButton::clicked,
            this, &HealthAssessmentWidget::on_assessButton_clicked);
    connect(ui->resetButton, &QPushButton::clicked,
            this, &HealthAssessmentWidget::on_resetButton_clicked);
}

HealthAssessmentWidget::~HealthAssessmentWidget()
{
    delete ui;
}

void HealthAssessmentWidget::on_assessButton_clicked()
{
    calculateAssessment();
}

void HealthAssessmentWidget::on_resetButton_clicked()
{
    ui->heightSpinBox->setValue(170);
    ui->weightSpinBox->setValue(65);
    ui->bpHighSpinBox->setValue(120);
    ui->bpLowSpinBox->setValue(80);
    ui->heartRateSpinBox->setValue(75);
    ui->resultTextEdit->clear();
}

void HealthAssessmentWidget::calculateAssessment()
{
    double heightVal = ui->heightSpinBox->value();
    double weightVal = ui->weightSpinBox->value();
    int bpHigh = ui->bpHighSpinBox->value();
    int bpLow = ui->bpLowSpinBox->value();
    int heartRate = ui->heartRateSpinBox->value();

    // 计算BMI
    double bmi = weightVal / ((heightVal / 100.0) * (heightVal / 100.0));
    QString bmiStatus = getBMICategory(bmi);
    QString bpStatus = getBPCategory(bpHigh, bpLow);
    QString hrStatus = getHeartRateCategory(heartRate);

    // 当前时间
    QString currentDate = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");

    // 构建显示文本
    QString result = QString("健康评估报告\n"
                             "评估时间: %1\n\n"
                             "身体指标:\n"
                             "身高: %2 cm\n"
                             "体重: %3 kg\n"
                             "血压: %4/%5 mmHg\n"
                             "心率: %6 次/分\n\n"
                             "评估结果:\n"
                             "BMI: %7 (%8)\n"
                             "血压: %9\n"
                             "心率: %10\n\n"
                             "健康建议:\n")
            .arg(currentDate)
            .arg(heightVal)
            .arg(weightVal)
            .arg(bpHigh).arg(bpLow)
            .arg(heartRate)
            .arg(bmi, 0, 'f', 1).arg(bmiStatus)
            .arg(bpStatus).arg(hrStatus);

    // 健康建议
    if (bmiStatus == "偏瘦") result += "• 建议增加营养摄入，适当增重\n";
    else if (bmiStatus == "正常") result += "• 保持当前体重和饮食习惯\n";
    else if (bmiStatus == "超重") result += "• 建议适当控制饮食，增加运动量\n";
    else result += "• 建议咨询医生制定减重计划\n";

    if (bpStatus.contains("偏高")) result += "• 注意控制盐分摄入，定期监测血压\n";
    else if (bpStatus.contains("偏低")) result += "• 注意增加水分摄入，避免突然站立\n";

    if (hrStatus.contains("偏快")) result += "• 避免过度紧张和咖啡因摄入\n";
    else if (hrStatus.contains("偏慢")) result += "• 如无不适症状，通常无需担心\n";

    result += "\n温馨提示: 本评估仅供参考，如有不适请及时就医";

    ui->resultTextEdit->setPlainText(result);

    // ------------------- 数据库录入 student_info -------------------
    QSqlDatabase db = QSqlDatabase::database();
    if (!db.isOpen()) {
        QMessageBox::critical(this, "数据库错误", "数据库未连接！");
        return;
    }

    QSqlQuery query(db);
    query.prepare("UPDATE student_info SET height = :height, weight = :weight, "
                  "high_blood = :bp_high, low_blood = :bp_low, heartrating = :heart_rate "
                  "WHERE student_id = :student_id");
    query.bindValue(":height", heightVal);
    query.bindValue(":weight", weightVal);
    query.bindValue(":bp_high", bpHigh);
    query.bindValue(":bp_low", bpLow);
    query.bindValue(":heart_rate", heartRate);
    query.bindValue(":student_id", g_studentId);

    if (!query.exec()) {
        QMessageBox::critical(this, "录入失败", "无法将评估结果保存到数据库: " + query.lastError().text());
    } else {
        QMessageBox::information(this, "录入成功", "健康评估数据已成功保存");
    }
}

QString HealthAssessmentWidget::getBMICategory(double bmi)
{
    if (bmi < 18.5) return "偏瘦";
    else if (bmi < 24) return "正常";
    else if (bmi < 28) return "超重";
    else return "肥胖";
}

QString HealthAssessmentWidget::getBPCategory(int systolic, int diastolic)
{
    if (systolic < 90 || diastolic < 60) return "偏低";
    else if (systolic <= 139 && diastolic <= 89) return "正常";
    else return "偏高";
}

QString HealthAssessmentWidget::getHeartRateCategory(int heartRate)
{
    if (heartRate < 60) return "偏慢";
    else if (heartRate <= 100) return "正常";
    else return "偏快";
}
