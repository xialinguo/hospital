#ifndef APPOINTMENTWIDGET_H
#define APPOINTMENTWIDGET_H

#include <QWidget>

// 前向声明UI命名空间中的类
namespace Ui {
class AppointmentWidget;
}

class AppointmentWidget : public QWidget
{
    Q_OBJECT

public:
    explicit AppointmentWidget(QWidget *parent = nullptr);
    ~AppointmentWidget();

private slots:
    void on_bookButton_clicked();
    void on_dateEdit_dateChanged(const QDate &date);

private:
    Ui::AppointmentWidget *ui;  // 使用指针
    void loadDoctors();
    void loadAvailableTimes();
};

#endif // APPOINTMENTWIDGET_H
