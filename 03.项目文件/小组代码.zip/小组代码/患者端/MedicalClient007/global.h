#ifndef GLOBAL_H
#define GLOBAL_H

#include <QString>

extern int g_studentId;   // 全局学号
extern QString g_userName; // 全局用户名（可选）

#endif // GLOBAL_H
