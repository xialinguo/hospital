#include "chatwidget.h"
#include "ui_chatwidget.h"
#include "global.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QHostAddress>
#include <QDebug>

ChatWidget::ChatWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ChatWidget),
    m_socket(new QTcpSocket(this))
{
    ui->setupUi(this);
    setWindowTitle("医患沟通");
    this->setStyleSheet("background-color: palette(window);");

    connect(m_socket, &QTcpSocket::connected, this, &ChatWidget::onConnected);
    connect(m_socket, &QTcpSocket::disconnected, this, &ChatWidget::onDisconnected);
    connect(m_socket, &QTcpSocket::readyRead, this, &ChatWidget::onReadyRead);
    connect(m_socket, SIGNAL(error(QAbstractSocket::SocketError)),
            this, SLOT(displayError(QAbstractSocket::SocketError)));

    updateUIState();
    loadDoctorList();
}

ChatWidget::~ChatWidget()
{
    delete ui;
}

void ChatWidget::showEvent(QShowEvent *event)
{
    QWidget::showEvent(event);
    if (m_isFirstShow) {
        m_isFirstShow = false;
        connectToServer();
    }
}

void ChatWidget::connectToServer()
{
    if (m_socket->state() == QAbstractSocket::UnconnectedState) {
        const QString serverIp = "60.205.162.162";
        const quint16 serverPort = 8765;
        ui->chatTextEdit->append("<i>正在连接到聊天服务器...</i>");
        m_socket->connectToHost(QHostAddress(serverIp), serverPort);
    }
}

void ChatWidget::registerWithServer()
{
    // 注册只发送患者工号
    QString regMsg = QString::number(g_studentId);
    m_socket->write(regMsg.toUtf8());
    m_socket->flush();
    qDebug() << "注册客户端工号:" << regMsg;
}

void ChatWidget::loadDoctorList()
{
    ui->doctorComboBox->clear();
    ui->doctorComboBox->addItem("请选择医生");

    QSqlQuery query;
    if (!query.exec("SELECT doctor_id, name FROM doctor_info ORDER BY name ASC")) {
        QMessageBox::critical(this, "数据库错误", "无法加载医生列表: " + query.lastError().text());
        return;
    }

    while (query.next()) {
        QString doctorId = query.value("doctor_id").toString();
        QString doctorName = query.value("name").toString();
        ui->doctorComboBox->addItem(doctorName, doctorId);
    }
}

void ChatWidget::on_doctorComboBox_currentIndexChanged(int index)
{
    if (index <= 0) {
        m_currentDoctorId.clear();
        ui->chatTextEdit->clear();
        ui->chatTextEdit->append("<i>请选择一位医生进行沟通</i>");
    } else {
        m_currentDoctorId = ui->doctorComboBox->itemData(index).toString();
        ui->chatTextEdit->clear();
        ui->chatTextEdit->append(QString("<b>--- 开始与 %1 的对话 ---</b>")
                                  .arg(ui->doctorComboBox->currentText()));
    }
    updateUIState();
}

void ChatWidget::on_sendButton_clicked()
{
    QString message = ui->textEdit->toPlainText().trimmed();
    if (message.isEmpty() || m_currentDoctorId.isEmpty() || g_studentId <= 0)
        return;

    QString formattedMessage = QString("%1|%2|%3")
                               .arg(QString::number(g_studentId), m_currentDoctorId, message);
    m_socket->write(formattedMessage.toUtf8());
    m_socket->flush();

    ui->chatTextEdit->append(QString("<p style='text-align:right; color:green;'><b>我:</b> %1</p>").arg(message));
    ui->textEdit->clear();
}

void ChatWidget::onConnected()
{
    ui->chatTextEdit->append("<i>✅ 已连接聊天服务器</i>");
    registerWithServer();
    updateUIState();
}

void ChatWidget::onDisconnected()
{
    ui->chatTextEdit->append("<i>❌ 已断开聊天服务器</i>");
    updateUIState();
}

void ChatWidget::onReadyRead()
{
    QByteArray data = m_socket->readAll();
    QString message = QString::fromUtf8(data);

    // server_app_v2 格式: senderId|targetId|content
    QStringList parts = message.split("|");
    if (parts.size() != 3)
        return;

    QString sender = parts[0];
    QString target = parts[1];
    QString content = parts[2];

    if (target == QString::number(g_studentId)) {
        ui->chatTextEdit->append(QString("<b>%1:</b> %2").arg(sender, content));
    }
}

void ChatWidget::displayError(QAbstractSocket::SocketError socketError)
{
    Q_UNUSED(socketError);
    if (m_socket->state() != QAbstractSocket::UnconnectedState) {
        QMessageBox::warning(this, "网络错误", m_socket->errorString());
    }
    updateUIState();
}

void ChatWidget::updateUIState()
{
    bool canSend = (m_socket->state() == QAbstractSocket::ConnectedState) && !m_currentDoctorId.isEmpty();
    ui->textEdit->setEnabled(canSend);
    ui->sendButton->setEnabled(canSend);
}
