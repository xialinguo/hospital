/********************************************************************************
** Form generated from reading UI file 'chatwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHATWIDGET_H
#define UI_CHATWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ChatWidget
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *titleLabel;
    QComboBox *doctorComboBox;
    QTextEdit *chatTextEdit;
    QTextEdit *textEdit;
    QPushButton *sendButton;
    QHBoxLayout *inputLayout;

    void setupUi(QWidget *ChatWidget)
    {
        if (ChatWidget->objectName().isEmpty())
            ChatWidget->setObjectName(QStringLiteral("ChatWidget"));
        ChatWidget->resize(400, 300);
        verticalLayout = new QVBoxLayout(ChatWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        titleLabel = new QLabel(ChatWidget);
        titleLabel->setObjectName(QStringLiteral("titleLabel"));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        titleLabel->setFont(font);
        titleLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(titleLabel);

        doctorComboBox = new QComboBox(ChatWidget);
        doctorComboBox->setObjectName(QStringLiteral("doctorComboBox"));

        verticalLayout->addWidget(doctorComboBox);

        chatTextEdit = new QTextEdit(ChatWidget);
        chatTextEdit->setObjectName(QStringLiteral("chatTextEdit"));
        chatTextEdit->setReadOnly(true);

        verticalLayout->addWidget(chatTextEdit);

        textEdit = new QTextEdit(ChatWidget);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setMaximumSize(QSize(16777215, 80));

        verticalLayout->addWidget(textEdit);

        sendButton = new QPushButton(ChatWidget);
        sendButton->setObjectName(QStringLiteral("sendButton"));
        sendButton->setMinimumSize(QSize(60, 30));

        verticalLayout->addWidget(sendButton);

        inputLayout = new QHBoxLayout();
        inputLayout->setObjectName(QStringLiteral("inputLayout"));
        inputLayout->setContentsMargins(-1, -1, -1, 0);

        verticalLayout->addLayout(inputLayout);


        retranslateUi(ChatWidget);

        QMetaObject::connectSlotsByName(ChatWidget);
    } // setupUi

    void retranslateUi(QWidget *ChatWidget)
    {
        ChatWidget->setWindowTitle(QApplication::translate("ChatWidget", "Form", Q_NULLPTR));
        titleLabel->setText(QApplication::translate("ChatWidget", "\345\214\273\346\202\243\346\262\237\351\200\232", Q_NULLPTR));
        chatTextEdit->setPlaceholderText(QApplication::translate("ChatWidget", "\350\201\212\345\244\251\350\256\260\345\275\225\345\260\206\346\230\276\347\244\272\345\234\250\350\277\231\351\207\214", Q_NULLPTR));
        textEdit->setPlaceholderText(QApplication::translate("ChatWidget", "\350\257\267\350\276\223\345\205\245\346\266\210\346\201\257...", Q_NULLPTR));
        sendButton->setText(QApplication::translate("ChatWidget", "\345\217\221\351\200\201", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ChatWidget: public Ui_ChatWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHATWIDGET_H
