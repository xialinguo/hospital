/********************************************************************************
** Form generated from reading UI file 'appointmentwidget.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_APPOINTMENTWIDGET_H
#define UI_APPOINTMENTWIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AppointmentWidget
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *titleLabel;
    QFormLayout *formLayout;
    QLabel *Label;
    QComboBox *doctorComboBox;
    QLabel *Label_2;
    QDateEdit *DateEdit;
    QLabel *Label_3;
    QComboBox *timeComboBox;
    QPushButton *bookButton;

    void setupUi(QWidget *AppointmentWidget)
    {
        if (AppointmentWidget->objectName().isEmpty())
            AppointmentWidget->setObjectName(QStringLiteral("AppointmentWidget"));
        AppointmentWidget->resize(400, 300);
        verticalLayout = new QVBoxLayout(AppointmentWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        titleLabel = new QLabel(AppointmentWidget);
        titleLabel->setObjectName(QStringLiteral("titleLabel"));
        QFont font;
        font.setPointSize(14);
        font.setBold(true);
        font.setWeight(75);
        titleLabel->setFont(font);
        titleLabel->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(titleLabel);

        formLayout = new QFormLayout();
        formLayout->setObjectName(QStringLiteral("formLayout"));
        Label = new QLabel(AppointmentWidget);
        Label->setObjectName(QStringLiteral("Label"));

        formLayout->setWidget(2, QFormLayout::LabelRole, Label);

        doctorComboBox = new QComboBox(AppointmentWidget);
        doctorComboBox->setObjectName(QStringLiteral("doctorComboBox"));

        formLayout->setWidget(2, QFormLayout::FieldRole, doctorComboBox);

        Label_2 = new QLabel(AppointmentWidget);
        Label_2->setObjectName(QStringLiteral("Label_2"));

        formLayout->setWidget(3, QFormLayout::LabelRole, Label_2);

        DateEdit = new QDateEdit(AppointmentWidget);
        DateEdit->setObjectName(QStringLiteral("DateEdit"));
        DateEdit->setCalendarPopup(true);

        formLayout->setWidget(3, QFormLayout::FieldRole, DateEdit);

        Label_3 = new QLabel(AppointmentWidget);
        Label_3->setObjectName(QStringLiteral("Label_3"));

        formLayout->setWidget(4, QFormLayout::LabelRole, Label_3);

        timeComboBox = new QComboBox(AppointmentWidget);
        timeComboBox->setObjectName(QStringLiteral("timeComboBox"));

        formLayout->setWidget(4, QFormLayout::FieldRole, timeComboBox);


        verticalLayout->addLayout(formLayout);

        bookButton = new QPushButton(AppointmentWidget);
        bookButton->setObjectName(QStringLiteral("bookButton"));
        bookButton->setMinimumSize(QSize(120, 40));

        verticalLayout->addWidget(bookButton);


        retranslateUi(AppointmentWidget);

        QMetaObject::connectSlotsByName(AppointmentWidget);
    } // setupUi

    void retranslateUi(QWidget *AppointmentWidget)
    {
        AppointmentWidget->setWindowTitle(QApplication::translate("AppointmentWidget", "Form", Q_NULLPTR));
        titleLabel->setText(QApplication::translate("AppointmentWidget", "\351\242\204\347\272\246\346\214\202\345\217\267", Q_NULLPTR));
        Label->setText(QApplication::translate("AppointmentWidget", "\351\200\211\346\213\251\345\214\273\347\224\237\357\274\232", Q_NULLPTR));
        Label_2->setText(QApplication::translate("AppointmentWidget", "\351\200\211\346\213\251\346\227\245\346\234\237\357\274\232", Q_NULLPTR));
        Label_3->setText(QApplication::translate("AppointmentWidget", "\351\200\211\346\213\251\346\227\266\351\227\264\357\274\232", Q_NULLPTR));
        bookButton->setText(QApplication::translate("AppointmentWidget", "\347\241\256\350\256\244\351\242\204\347\272\246", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class AppointmentWidget: public Ui_AppointmentWidget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_APPOINTMENTWIDGET_H
