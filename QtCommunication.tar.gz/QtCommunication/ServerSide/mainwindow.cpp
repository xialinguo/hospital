#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QHostAddress>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , server(new QTcpServer(this))
    , clientSocket(nullptr)
{
    ui->setupUi(this);

    // 当有新客户端连接时，触发 newClientConnection
    connect(server, &QTcpServer::newConnection, this, &MainWindow::newClientConnection);

    // 自动填充默认IP和端口
    ui->lineEditIP->setText("127.0.0.1");
    ui->lineEditPort->setText("12345");
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_startServerButton_clicked()
{
    QString ip = ui->lineEditIP->text();
    quint16 port = ui->lineEditPort->text().toUShort();

    if(!server->listen(QHostAddress(ip), port)) {
        QMessageBox::critical(this, "错误", "服务器启动失败: " + server->errorString());
    } else {
        ui->textEditLog->append("服务器已启动，监听 " + ip + ":" + QString::number(port));
    }
}

void MainWindow::newClientConnection()
{
    clientSocket = server->nextPendingConnection();
    ui->textEditLog->append("有新客户端连接进来。");

    connect(clientSocket, &QTcpSocket::readyRead, this, &MainWindow::readClientData);
}

void MainWindow::readClientData()
{
    QByteArray data = clientSocket->readAll();
    QString msg = QString::fromUtf8(data);

    ui->textEditLog->append("收到客户端消息: " + msg);

    // 回复消息
    clientSocket->write("服务器已收到: " + msg.toUtf8());
}
