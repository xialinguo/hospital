#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QHostAddress>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , socket(new QTcpSocket(this))
{
    ui->setupUi(this);

    // 自动填充 IP 和端口
    ui->ipLineEdit->setText("127.0.0.1");
    ui->portLineEdit->setText("12345");

    // 连接 socket 的信号槽
    connect(socket, &QTcpSocket::readyRead, this, &MainWindow::onReadyRead);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_connectButton_clicked()
{
    QString ip = ui->ipLineEdit->text();
    quint16 port = ui->portLineEdit->text().toUShort();

    socket->connectToHost(QHostAddress(ip), port);

    if (socket->waitForConnected(3000)) {
        ui->textBrowser->append("✅ 连接成功！");
    } else {
        ui->textBrowser->append("❌ 连接失败！");
    }
}

void MainWindow::on_sendButton_clicked()
{
    QString msg = ui->msgLineEdit->text();
    if (!msg.isEmpty()) {
        socket->write(msg.toUtf8());
        ui->textBrowser->append("客户端: " + msg);
        ui->msgLineEdit->clear();
    }
}

void MainWindow::onReadyRead()
{
    QByteArray data = socket->readAll();
    ui->textBrowser->append("服务器: " + QString::fromUtf8(data));
}
