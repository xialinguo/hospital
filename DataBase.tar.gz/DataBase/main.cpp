#include "mainwindow.h"
#include <QApplication>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // 连接 SQLite 数据库（会自动在程序目录下生成 student.db 文件）
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("student.db");

    if (!db.open()) {
        qDebug() << "数据库打开失败！";
        return -1;
    }

    // 如果没有表，就创建一个
    QSqlQuery query;
    query.exec("CREATE TABLE IF NOT EXISTS student ("
               "sid INTEGER PRIMARY KEY, "
               "name TEXT, "
               "age INTEGER)");

    MainWindow w;
    w.show();
    return a.exec();
}
