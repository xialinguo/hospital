#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 建立数据模型
    model = new QSqlTableModel(this);
    model->setTable("student");   // 绑定 student 表
    model->select();              // 读取数据

    // 设置显示到表格
    ui->tableView->setModel(model);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectRows); // 整行选择
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);  // 不允许直接编辑
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 添加
void MainWindow::on_addButton_clicked()
{
    QString sid = ui->sidLineEdit->text();
    QString name = ui->nameLineEdit->text();
    QString age = ui->ageLineEdit->text();

    if (sid.isEmpty() || name.isEmpty() || age.isEmpty()) {
        QMessageBox::warning(this, "错误", "请填写完整信息！");
        return;
    }

    QSqlQuery query;
    query.prepare("INSERT INTO student (sid, name, age) VALUES (?, ?, ?)");
    query.addBindValue(sid);
    query.addBindValue(name);
    query.addBindValue(age);

    if (!query.exec()) {
        QMessageBox::critical(this, "插入失败", query.lastError().text());
    }

    model->select(); // 刷新表格
}

// 删除
void MainWindow::on_deleteButton_clicked()
{
    QString sid = ui->sidLineEdit->text();
    if (sid.isEmpty()) {
        QMessageBox::warning(this, "错误", "请先输入 sid！");
        return;
    }

    QSqlQuery query;
    query.prepare("DELETE FROM student WHERE sid = ?");
    query.addBindValue(sid);

    if (!query.exec()) {
        QMessageBox::critical(this, "删除失败", query.lastError().text());
    }

    model->select();
}

// 修改
void MainWindow::on_updateButton_clicked()
{
    QString sid = ui->sidLineEdit->text().trimmed();
    QString name = ui->nameLineEdit->text().trimmed();
    QString age = ui->ageLineEdit->text().trimmed();

    if (sid.isEmpty()) {
        QMessageBox::warning(this, "错误", "请先输入 sid！");
        return;
    }

    QSqlQuery query;
    query.prepare("UPDATE student SET name = ?, age = ? WHERE sid = ?");
    query.addBindValue(name);
    query.addBindValue(age);
    query.addBindValue(sid);

    if (!query.exec()) {
        QMessageBox::critical(this, "修改失败", query.lastError().text());
    } else if (query.numRowsAffected() == 0) {
        QMessageBox::information(this, "提示", "没有找到该 sid，无法修改！");
    }

    model->select(); // 刷新表格
}

// 查询（按 sid）
void MainWindow::on_searchButton_clicked()
{
    QString sid = ui->sidLineEdit->text().trimmed(); // 去掉空格
    if (sid.isEmpty()) {
        QMessageBox::warning(this, "错误", "请输入学号部分内容！");
        return;
    }

    // 模糊查询：sid 里包含输入的字符串
    model->setFilter(QString("sid LIKE '%%1%'").arg(sid));
    model->select();

    if (model->rowCount() == 0) {
        QMessageBox::information(this, "提示", "没有找到匹配的数据！");
    }
}


// 刷新（显示全部）
void MainWindow::on_refreshButton_clicked()
{
    model->setFilter(""); // 去掉过滤条件
    model->select();
}
